﻿# Mi Musica 1.8: convierte tus canciones a .ogg (el formato de Minecraft), las numera,
# iguala su volumen, las identifica y busca su letra sincronizada.
# Solo procesa lo nuevo: las canciones que ya estaban no se vuelven a convertir.
# Para revisar, corregir o elegir otra letra abre PREPARAR_CANCIONES.bat.
# ---- Ajustes ----
# Si una cancion no tiene letra en internet, se escucha con IA (Whisper) y se escribe su letra
# palabra por palabra. La primera vez descarga unos 160 MB. Pon $false para no usarla.
$usarIA = $true
# Modelo de la IA: "base" (rapido), "small" (mejor con canto, 480 MB, mas lento) o "medium" (el mejor, 1.5 GB).
$modeloIA = "base"
# Buscar los subtitulos del video de YouTube de cada cancion.
$usarYouTube = $true
# Pasar las letras que solo tienen tiempo por linea a palabra por palabra con la IA (1-2 min por cancion).
$sincronizarPalabras = $false
# Confianza minima (0-100) para usar una letra sin preguntarte. Las de menos quedan "por revisar".
$confianzaMinima = 60
# Opcional: clave gratis de https://acoustid.org/new-application para reconocer canciones por su sonido
# (sirve cuando el archivo tiene un nombre raro y no trae datos).
$acoustidKey = ""
# ------------------
$pack = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot "comun.ps1")
[Console]::OutputEncoding = [Text.Encoding]::UTF8

Write-Host ""
Write-Host "  ♪  Mi Musica - agregar canciones  ♪" -ForegroundColor Magenta
Write-Host ""

# 1. ffmpeg (para convertir). Se descarga una sola vez (unos 90 MB).
$ff = Get-FF
$script:ff = $ff
# 2. Lo que ya estaba: numero|archivo|tamano por cancion, y los nombres que hayas cambiado.
$known = @{}   # "archivo|tamano" -> numero
if (-not (Test-Path $index)) {
    # Primera vez con esta version: se empieza limpio.
    Remove-Item (Join-Path $snd "*.ogg"), (Join-Path $lrc "*.lrc"), (Join-Path $rit "*.txt"), (Join-Path $infoD "*.txt"), (Join-Path $datos "*.json"), $names -ErrorAction SilentlyContinue
}
if (Test-Path $index) {
    foreach ($l in [IO.File]::ReadAllLines($index, $utf8)) {
        $p = $l.Split("|")
        if ($p.Count -ge 3 -and (Test-Path (Join-Path $snd "$($p[0]).ogg"))) { $known["$($p[1])|$($p[2])"] = [int]$p[0] }
    }
}
$oldNames = @{}
if (Test-Path $names) {
    foreach ($l in [IO.File]::ReadAllLines($names, $utf8)) {
        if ($l -match '^\s*(\d+)\s*=\s*(.+)$') { $oldNames[[int]$Matches[1]] = $Matches[2].Trim() }
    }
}

# 3. Las canciones de la carpeta (maximo 100).
$exts = ".mp3",".m4a",".wav",".flac",".ogg",".opus",".webm",".aac",".wma",".mp4",".mkv"
$files = @(Get-ChildItem $src -File | Where-Object { $exts -contains $_.Extension.ToLower() } | Sort-Object Name | Select-Object -First 100)
if ($files.Count -eq 0) { Write-Host "No hay canciones en PON_TUS_CANCIONES_AQUI." -ForegroundColor Red; exit }

$slots = @{}   # numero -> archivo
$todo = @()
foreach ($f in $files) {
    $key = "$($f.Name)|$($f.Length)"
    if ($known.ContainsKey($key)) { $slots[$known[$key]] = $f } else { $todo += $f }
}
# Los numeros de canciones que quitaste quedan libres (y se borran sus archivos).
foreach ($k in @($known.Values)) {
    if (-not $slots.ContainsKey($k)) {
        Remove-Item (Join-Path $snd "$k.ogg"), (Join-Path $lrc "$k.lrc"), (Join-Path $rit "$k.txt"), (Join-Path $infoD "$k.txt"), (Data-Path $k) -ErrorAction SilentlyContinue
    }
}
# Los nombres de numeros que ahora son de otra cancion no se conservan.
foreach ($k in @($oldNames.Keys)) { if (-not $slots.ContainsKey($k)) { $oldNames.Remove($k) } }
$free = @(1..100 | Where-Object { -not $slots.ContainsKey($_) })
$jobs = @()
$i = 0
foreach ($f in $todo) { $slots[$free[$i]] = $f; $jobs += ,@($free[$i], $f); $i++ }
Write-Host ("Canciones: {0}  (ya estaban {1}, nuevas {2})" -f $files.Count, ($files.Count - $todo.Count), $todo.Count) -ForegroundColor Cyan

# 4. Convertir lo nuevo, varias a la vez, con el volumen igualado (todas suenan parecido).
$max = [Math]::Max(2, [Math]::Min(6, [Environment]::ProcessorCount))
$running = @()
$done = 0
$failed = @()
$queue = New-Object System.Collections.Queue
foreach ($j in $jobs) { $queue.Enqueue($j) }
while ($queue.Count -gt 0 -or $running.Count -gt 0) {
    while ($queue.Count -gt 0 -and $running.Count -lt $max) {
        $j = $queue.Dequeue()
        $out = Join-Path $snd "$($j[0]).ogg"
        $argline = "-hide_banner -loglevel error -y -i `"$($j[1].FullName)`" -vn -map_metadata -1 -af loudnorm=I=-14:TP=-1.5:LRA=11 -ac 2 -ar 44100 -c:a libvorbis -q:a 5 `"$out`""
        $proc = Start-Process -FilePath $ff -ArgumentList $argline -NoNewWindow -PassThru
        $running += ,@($proc, $j)
    }
    Start-Sleep -Milliseconds 200
    $still = @()
    foreach ($r in $running) {
        if ($r[0].HasExited) {
            $done++
            $n = $r[1][0]; $f = $r[1][1]
            if (Test-Path (Join-Path $snd "$n.ogg")) { Write-Host ("  ✓ [{0}] {1}" -f $n, $f.BaseName) -ForegroundColor Green }
            else { Write-Host ("  ✗ no se pudo convertir: {0}" -f $f.Name) -ForegroundColor Red; $failed += $n }
        } else { $still += ,$r }
    }
    $running = $still
    if ($jobs.Count -gt 0) {
        Write-Progress -Activity "Convirtiendo canciones" -Status "$done de $($jobs.Count)" -PercentComplete ([int](100 * $done / $jobs.Count))
    }
}
Write-Progress -Activity "Convirtiendo canciones" -Completed
foreach ($n in $failed) { $slots.Remove($n) }

# 5. Identificar cada cancion y buscar su letra. Se buscan TODAS las coincidencias (lrclib, NetEase,
#    MusicBrainz, Megalobiz y, si pusiste la clave, AcoustID), se comparan por duracion, titulo y
#    artista, y se usa la de mas confianza. Las demas quedan guardadas para elegir otra en el preparador.
#    Las canciones que corregiste o bloqueaste en PREPARAR_CANCIONES no se tocan.
$links = @{}
$linkFile = Join-Path $src "enlaces.txt"
if (-not (Test-Path $linkFile)) {
    [IO.File]::WriteAllText($linkFile, "# Si una cancion no encuentra su letra, pon aqui su video de YouTube, uno por linea:`r`n# parte del nombre del archivo = https://www.youtube.com/watch?v=...`r`n", $utf8)
}
foreach ($l in [IO.File]::ReadAllLines($linkFile, $utf8)) {
    if ($l -match "^\s*([^#].*?)\s*=\s*(https?://\S+)") { $links[$Matches[1]] = $Matches[2] }
}

$withLyrics = 0; $toCheck = 0
$order = $slots.Keys | Sort-Object
$auto = @{}   # numero -> titulo automatico
$k = 0
foreach ($n in $order) {
    $k++
    $f = $slots[$n]
    $dest = Join-Path $lrc "$n.lrc"
    Write-Progress -Activity "Identificando canciones y buscando letras" -Status $f.BaseName -PercentComplete ([int](100 * $k / $order.Count))
    $d = Read-Data $n
    $tags = Get-Tags $f.FullName
    $secs = Get-Seconds (Join-Path $snd "$n.ogg")
    $d.archivo = $f.Name; $d.duracion = [Math]::Round($secs, 2)
    $want = Get-Want $tags $f.BaseName $secs
    $nice = if ($want.artist) { "$($want.artist) - $($want.title)" } else { $want.title }

    # Tu propio .lrc manda siempre.
    $own = Join-Path $src ($f.BaseName + ".lrc")
    if (Test-Path $own) {
        $text = [IO.File]::ReadAllText($own, $utf8)
        if ($text -match "\[ti:\s*(.+?)\]") { $d.titulo = $Matches[1] } elseif (-not $d.titulo) { $d.titulo = $want.title }
        if ($text -match "\[ar:\s*(.+?)\]") { $d.artista = $Matches[1] } elseif (-not $d.artista) { $d.artista = $want.artist }
        $d.fuente = "tu .lrc"; $d.id = "propio"; $d.confianza = 100; $d.tipo = Lyric-Kind $text; $d.manual = $true
        Save-Lyrics $n $d $text $(if ($text -match "\[offset:\s*(-?\d+)\]") { [int]$Matches[1] } else { $d.offset })
        Write-Info $n $d; Write-Data $n $d
    }
    # Ya identificada antes (o corregida/bloqueada por ti): no se vuelve a buscar.
    if ($d.manual -or $d.bloqueada -or ($d.fuente -and ((Test-Path $dest) -or $d.tipo -eq "instrumental" -or $d.tipo -eq "ninguna"))) {
        if ($d.tipo -and $d.tipo -ne "ninguna" -and $d.tipo -ne "instrumental") { $withLyrics++ }
        if ($d.artista -or $d.titulo) { $nice = ("$($d.artista) - $($d.titulo)").Trim(" -") }
        Write-Info $n $d; Write-Data $n $d
        $auto[$n] = $nice
        continue
    }
    # Letras de una version anterior del paquete (sin datos): se conservan y se marcan.
    if ((Test-Path $dest) -and -not $d.fuente) {
        $head = [IO.File]::ReadAllText($dest, $utf8)
        if ($head -match "\[ti:\s*(.+?)\]") { $d.titulo = $Matches[1] }
        if ($head -match "\[ar:\s*(.+?)\]") { $d.artista = $Matches[1] }
        $d.fuente = "anterior"; $d.confianza = -1; $d.tipo = Lyric-Kind $head
        Write-Info $n $d; Write-Data $n $d
        $withLyrics++; $auto[$n] = ("$($d.artista) - $($d.titulo)").Trim(" -"); if (-not $auto[$n]) { $auto[$n] = $nice }
        continue
    }

    $script:netErr = ""
    $cands = Find-Candidates $want $f.FullName $d.descartadas
    $d.candidatos = Cands-ForSave $cands
    if (-not $d.artista) { $d.artista = $want.artist }
    if (-not $d.titulo) { $d.titulo = $want.title }
    $best = $cands | Where-Object { $_.tipo -ne "texto" } | Select-Object -First 1
    $instr = $cands | Where-Object { $_.tipo -eq "instrumental" -and $_.confianza -ge 70 } | Select-Object -First 1
    if ($instr -and (-not $best -or $best.tipo -eq "instrumental" -or $want.instrumental)) {
        Apply-Cand $n $d $instr
        Write-Host ("  ♪ [{0}] instrumental (sin letra): {1}" -f $n, $nice) -ForegroundColor Cyan
        $auto[$n] = ("$($d.artista) - $($d.titulo)").Trim(" -")
        continue
    }
    if ($best -and $best.confianza -ge $confianzaMinima) {
        Apply-Cand $n $d $best
        $withLyrics++
        $nice = ("$($d.artista) - $($d.titulo)").Trim(" -")
        $col = if ($best.confianza -ge 85) { "Green" } elseif ($best.confianza -ge 70) { "DarkGreen" } else { "Yellow" }
        if ($best.confianza -lt 70) { $toCheck++ }
        Write-Host ("  ♫ [{0}] {1}  ({2}, {3}%, {4})" -f $n, $nice, $best.fuente, $best.confianza, $best.tipo) -ForegroundColor $col
        if ($sincronizarPalabras -and $usarIA -and $d.tipo -eq "linea") {
            Write-Host ("  … [{0}] sincronizando palabra por palabra con IA..." -f $n) -ForegroundColor Cyan
            $al = Align-Words ([IO.File]::ReadAllText($dest, $utf8)) (Whisper-Words (Join-Path $snd "$n.ogg"))
            if ($al) { $d.tipo = "palabra"; $d.fuente = "$($d.fuente)+IA"; Save-Lyrics $n $d $al.lrc $d.offset; Write-Info $n $d; Write-Data $n $d; Write-Host ("  ✦ [{0}] palabras alineadas ({1}% oidas)" -f $n, $al.hit) -ForegroundColor Green }
        }
        $auto[$n] = $nice
        continue
    }
    # YouTube: los subtitulos del video de esta cancion.
    $link = $null
    foreach ($key in $links.Keys) { if ($f.BaseName -like "*$key*") { $link = $links[$key] } }
    if ($usarYouTube -or $link) {
        $yt = YouTube $want.query $secs $link
        if ($yt) {
            $yt.artista = $want.artist; $yt.titulo = $want.title
            Apply-Cand $n $d $yt
            $withLyrics++; $toCheck++
            Write-Host ("  ♫ [{0}] letra de los subtitulos de YouTube: {1} ({2}%)" -f $n, $nice, $yt.confianza) -ForegroundColor Yellow
            $auto[$n] = $nice
            continue
        }
    }
    # La mejor aunque tenga poca confianza (mejor que nada); queda "por revisar".
    if ($best -and $best.confianza -ge 50) {
        Apply-Cand $n $d $best
        $withLyrics++; $toCheck++
        $nice = ("$($d.artista) - $($d.titulo)").Trim(" -")
        Write-Host ("  ~ [{0}] {1}: confianza baja ({2}%), revisala en PREPARAR_CANCIONES" -f $n, $nice, $best.confianza) -ForegroundColor Yellow
        $auto[$n] = $nice
        continue
    }
    # IA: escucha la cancion y escribe lo que se canta.
    if ($usarIA) {
        Write-Host ("  … [{0}] {1}: escuchando la cancion con IA (tarda un poco)..." -f $n, $nice) -ForegroundColor Cyan
        $words = Whisper-Words (Join-Path $snd "$n.ogg")
        $ai = $null
        if ($words.Count -ge 12) { $ai = Whisper (Join-Path $snd "$n.ogg") $secs }
        if ($ai) {
            $c = New-Cand "ia" "whisper" $want.artist $want.title $secs "palabra" $ai
            $c.confianza = 40
            Apply-Cand $n $d $c
            $withLyrics++; $toCheck++
            Write-Host ("  ♫ [{0}] letra escrita por la IA: {1}" -f $n, $nice) -ForegroundColor Green
            $auto[$n] = $nice
            continue
        }
        if ($words.Count -lt 4) {
            # La IA no oye voz: casi seguro es instrumental.
            $c = New-Cand "ia" "sin-voz" $want.artist $want.title $secs "instrumental" ""
            $c.confianza = 65
            Apply-Cand $n $d $c
            Write-Host ("  ♪ [{0}] {1}: no se oye voz, se marca como instrumental" -f $n, $nice) -ForegroundColor Cyan
            $auto[$n] = $nice
            continue
        }
    }
    # Solo letra sin tiempos: repartida a lo largo de la cancion (aproximada).
    $plain = $cands | Where-Object { $_.tipo -eq "texto" -and $_.confianza -ge 50 } | Select-Object -First 1
    if ($plain) {
        Apply-Cand $n $d $plain
        $withLyrics++; $toCheck++
        Write-Host ("  ~ [{0}] letra aproximada (sin tiempos exactos): {1}" -f $n, $nice) -ForegroundColor Yellow
        $auto[$n] = ("$($d.artista) - $($d.titulo)").Trim(" -")
        continue
    }
    $d.fuente = "ninguna"; $d.tipo = "ninguna"; $d.confianza = 0
    Write-Info $n $d; Write-Data $n $d
    $auto[$n] = $nice
    $why = if ($script:netErr) { "error: $($script:netErr)" } else { "no esta en internet (eligela a mano en PREPARAR_CANCIONES o pon un .lrc)" }
    Write-Host ("  · [{0}] {1}: sin letra ({2})" -f $n, $nice, $why) -ForegroundColor DarkYellow
}
Write-Progress -Activity "Identificando canciones y buscando letras" -Completed

# 6. Ritmo: lo fuerte que suena cada momento (cada 50 ms), para que la letra y las barras se muevan con la musica.
$k = 0
foreach ($n in $order) {
    $k++
    $dest = Join-Path $rit "$n.txt"
    if ((Test-Path $dest) -and ([IO.File]::ReadAllText($dest).Contains("`n"))) { continue }
    Write-Progress -Activity "Calculando el ritmo" -Status $slots[$n].BaseName -PercentComplete ([int](100 * $k / $order.Count))
    # Dos lineas: lo fuerte que suena todo, y lo fuerte que suenan los bajos (donde estan los golpes).
    $rows = @()
    foreach ($filt in "", "lowpass=f=150,lowpass=f=150,") {
        $lines2 = & $ff -hide_banner -nostats -i (Join-Path $snd "$n.ogg") -af ($filt + "aresample=8000,asetnsamples=n=400:p=0,astats=metadata=1:reset=1,ametadata=mode=print:key=lavfi.astats.Overall.RMS_level:file=-") -f null - 2>$null
        $vals = New-Object System.Collections.Generic.List[double]
        foreach ($l in $lines2) {
            if ($l -match "RMS_level=(.+)$") {
                $v = $Matches[1].Trim()
                if ($v -match "inf|nan") { $vals.Add(-90.0) } else { $vals.Add([double]::Parse($v, $inv)) }
            }
        }
        if ($vals.Count -eq 0) { break }
        $top = ($vals | Measure-Object -Maximum).Maximum
        $sb = New-Object Text.StringBuilder
        foreach ($v in $vals) { [void]$sb.Append([Math]::Max(0, [Math]::Min(9, [int][Math]::Round(($v - ($top - 24)) / 24 * 9)))) }
        $rows += $sb.ToString()
    }
    if ($rows.Count -eq 0) { Write-Host ("  · [{0}] no se pudo calcular el ritmo" -f $n) -ForegroundColor DarkYellow; continue }
    [IO.File]::WriteAllText($dest, (($rows -join "`n") + "`n"), $utf8)
}
Write-Progress -Activity "Calculando el ritmo" -Completed
Write-Host "  ♥ ritmo listo" -ForegroundColor Green

# 7. Nombres e indice. Un nombre que cambiaste a mano se conserva; los automaticos se mejoran.
$oldAuto = @{}
if (Test-Path $index) {
    foreach ($l in [IO.File]::ReadAllLines($index, $utf8)) { $p = $l.Split("|"); if ($p.Count -ge 4) { $oldAuto[[int]$p[0]] = $p[3] } }
}
$lines = @("# Numero=Nombre que se ve en el juego. Si cambias un nombre aqui, se conserva.")
$idx = @()
foreach ($n in $order) {
    $f = $slots[$n]
    $a = if ($auto.ContainsKey($n)) { $auto[$n] } else { Clean $f.BaseName }
    $a = $a -replace "[|=\r\n]", " "
    $name = $a
    if ($oldNames.ContainsKey($n)) {
        $o = $oldNames[$n]
        $wasAuto = ($o -eq $f.BaseName) -or ($oldAuto.ContainsKey($n) -and $o -eq $oldAuto[$n])
        if (-not $wasAuto) { $name = $o }
    }
    $lines += "$n=$name"
    $idx += "$n|$($f.Name)|$($f.Length)|$a"
    Write-Host ("  [{0}] {1}" -f $n, $name) -ForegroundColor Gray
}
[IO.File]::WriteAllLines($names, $lines, $utf8)
[IO.File]::WriteAllLines($index, $idx, $utf8)

Write-Host ""
Write-Host ("Listo: {0} canciones, {1} con letra." -f $order.Count, $withLyrics) -ForegroundColor Magenta
if ($toCheck -gt 0) { Write-Host ("{0} tienen poca confianza: abre PREPARAR_CANCIONES.bat para revisarlas o elegir otra letra." -f $toCheck) -ForegroundColor Yellow }
Write-Host "En Minecraft activa el paquete 'Mi Musica' (Opciones > Paquetes de recursos),"
Write-Host "o si ya esta activo pulsa F3+T. Luego J abre el menu y M reproduce."
Write-Host "Para corregir artista, titulo o letra, elegir otra coincidencia o bloquear una letra: PREPARAR_CANCIONES.bat."
Write-Host "Si una letra va un poco adelantada o atrasada, ajustala en el menu (J > Musica > Sincronia)."
