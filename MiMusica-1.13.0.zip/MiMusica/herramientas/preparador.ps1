﻿# Mi Musica 1.8 - Preparar canciones: revisa como se identifico cada cancion, elige otra
# coincidencia, corrige artista, titulo y letra, ajusta el desfase y bloquea letras.
$pack = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot "comun.ps1")
$acoustidKey = ""
# La clave de AcoustID se lee de agregar.ps1 si la pusiste alli.
$cfg = [IO.File]::ReadAllText((Join-Path $PSScriptRoot "agregar.ps1"), $utf8)
if ($cfg -match '(?m)^\$acoustidKey\s*=\s*"([^"]*)"') { $acoustidKey = $Matches[1] }
if ($cfg -match '(?m)^\$modeloIA\s*=\s*"([^"]*)"') { $modeloIA = $Matches[1] }
$script:ff = Get-FF

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
[Windows.Forms.Application]::EnableVisualStyles()

$violet = [Drawing.Color]::FromArgb(179, 107, 255)
$dark = [Drawing.Color]::FromArgb(26, 16, 41)
$panelC = [Drawing.Color]::FromArgb(38, 26, 58)
$textC = [Drawing.Color]::FromArgb(235, 228, 250)
$font = New-Object Drawing.Font("Segoe UI", 9)
$mono = New-Object Drawing.Font("Consolas", 10)

$form = New-Object Windows.Forms.Form
$form.Text = "♪ Mi Música - preparar canciones"
$form.Size = New-Object Drawing.Size(1180, 760)
$form.MinimumSize = New-Object Drawing.Size(1000, 640)
$form.StartPosition = "CenterScreen"
$form.BackColor = $dark; $form.ForeColor = $textC; $form.Font = $font

function New-Btn($text, $x, $y, $w, $tip) {
    $b = New-Object Windows.Forms.Button
    $b.Text = $text; $b.Location = New-Object Drawing.Point($x, $y); $b.Size = New-Object Drawing.Size($w, 28)
    $b.FlatStyle = "Flat"; $b.BackColor = $panelC; $b.ForeColor = $textC; $b.FlatAppearance.BorderColor = $violet
    if ($tip) { $script:tips.SetToolTip($b, $tip) }
    $form.Controls.Add($b)
    return $b
}
function New-Lbl($text, $x, $y, $w) {
    $l = New-Object Windows.Forms.Label
    $l.Text = $text; $l.Location = New-Object Drawing.Point($x, $y); $l.Size = New-Object Drawing.Size($w, 20); $l.ForeColor = $textC
    $form.Controls.Add($l)
    return $l
}
function New-Box($x, $y, $w) {
    $t = New-Object Windows.Forms.TextBox
    $t.Location = New-Object Drawing.Point($x, $y); $t.Size = New-Object Drawing.Size($w, 24)
    $t.BackColor = $panelC; $t.ForeColor = $textC; $t.BorderStyle = "FixedSingle"
    $form.Controls.Add($t)
    return $t
}
function New-List($x, $y, $w, $h, $cols) {
    $v = New-Object Windows.Forms.ListView
    $v.Location = New-Object Drawing.Point($x, $y); $v.Size = New-Object Drawing.Size($w, $h)
    $v.View = "Details"; $v.FullRowSelect = $true; $v.HideSelection = $false; $v.MultiSelect = $false
    $v.BackColor = $panelC; $v.ForeColor = $textC; $v.BorderStyle = "FixedSingle"
    foreach ($c in $cols) { [void]$v.Columns.Add($c[0], $c[1]) }
    $form.Controls.Add($v)
    return $v
}
$script:tips = New-Object Windows.Forms.ToolTip

# ---- izquierda: buscador y lista de canciones
$search = New-Box 10 10 340
$script:tips.SetToolTip($search, "Buscar por artista o titulo")
$hint = New-Lbl "Buscar artista o título…" 14 13 200; $hint.ForeColor = [Drawing.Color]::Gray; $hint.BackColor = $panelC
$hint.Add_Click({ $search.Focus() })
$hint.BringToFront()
$songs = New-List 10 40 340 600 @(@("#", 34), @("Canción", 176), @("Estado", 78), @("Conf.", 46))
$songs.Anchor = "Top,Bottom,Left"
$legend = New-Lbl "Verde: segura · Amarillo: revisar · Rojo: sin letra · Azul: instrumental · 🔒 bloqueada" 10 646 600
$legend.Anchor = "Bottom,Left"; $legend.ForeColor = [Drawing.Color]::FromArgb(170, 155, 200)

# ---- derecha: la cancion elegida
$X = 362
$info = New-Lbl "Elige una canción de la lista." $X 10 790; $info.Height = 36; $info.Anchor = "Top,Left,Right"
New-Lbl "Artista" $X 52 60 | Out-Null
$artist = New-Box ($X + 60) 49 260
New-Lbl "Título" ($X + 335) 52 50 | Out-Null
$title = New-Box ($X + 385) 49 300
$btnFind = New-Btn "🔍 Buscar letra" ($X + 695) 47 110 "Busca con el artista, el titulo y la duracion de tu archivo en lrclib, NetEase, MusicBrainz y Megalobiz."
$btnYT = New-Btn "YouTube" $X 82 90 "Usa los subtitulos del video de YouTube que dure igual."
$btnLink = New-Btn "Pegar enlace…" ($X + 95) 82 110 "Usa los subtitulos de un video exacto de YouTube."
$btnAI = New-Btn "Escuchar con IA" ($X + 210) 82 120 "La IA escucha la cancion y escribe la letra (1-2 minutos)."
$btnAlign = New-Btn "Palabra por palabra (IA)" ($X + 335) 82 170 "La IA escucha la cancion y pone cada palabra de la letra de abajo en su momento exacto."
$btnOpen = New-Btn "▶ Escuchar" ($X + 510) 82 90 "Abre tu archivo con tu reproductor."
$btnFolder = New-Btn "Abrir carpeta" ($X + 605) 82 105 ""

New-Lbl "Coincidencias encontradas (la mejor arriba). Haz clic para ver su letra:" $X 116 600 | Out-Null
$cands = New-List $X 136 795 170 @(@("Fuente", 75), @("Artista", 190), @("Título", 250), @("Duración", 70), @("Dif.", 55), @("Tipo", 80), @("Conf.", 55))
$cands.Anchor = "Top,Left,Right"
$lyrLbl = New-Lbl "Letra (puedes editarla; [mm:ss.xx] marca cada línea y <mm:ss.xx> cada palabra):" $X 312 600
$lyrics = New-Object Windows.Forms.TextBox
$lyrics.Multiline = $true; $lyrics.ScrollBars = "Both"; $lyrics.WordWrap = $false; $lyrics.AcceptsReturn = $true
$lyrics.Location = New-Object Drawing.Point($X, 332); $lyrics.Size = New-Object Drawing.Size(795, 290)
$lyrics.Font = $mono; $lyrics.BackColor = [Drawing.Color]::FromArgb(18, 12, 28); $lyrics.ForeColor = $textC
$lyrics.Anchor = "Top,Bottom,Left,Right"
$form.Controls.Add($lyrics)

$offLbl = New-Lbl "Desfase (ms):" $X 634 85; $offLbl.Anchor = "Bottom,Left"
$offset = New-Object Windows.Forms.NumericUpDown
$offset.Location = New-Object Drawing.Point(($X + 88), 631); $offset.Size = New-Object Drawing.Size(80, 24)
$offset.Minimum = -10000; $offset.Maximum = 10000; $offset.Increment = 50; $offset.Anchor = "Bottom,Left"
$script:tips.SetToolTip($offset, "Positivo: la letra sale antes. Negativo: sale despues. Es lo mismo que J > Sincronia en el juego, pero solo para esta cancion.")
$form.Controls.Add($offset)
$btnUse = New-Btn "✔ Usar esta" ($X + 180) 629 100 "Usa la coincidencia elegida."
$btnSave = New-Btn "💾 Guardar cambios" ($X + 285) 629 135 "Guarda el artista, el titulo, la letra de arriba y el desfase como tuyos."
$btnInstr = New-Btn "♪ Instrumental" ($X + 425) 629 110 "Esta cancion no tiene letra: no se busca mas y el juego muestra su nombre."
$btnDrop = New-Btn "✖ Descartar letra" ($X + 540) 629 125 "Esta letra es incorrecta: se quita y no se vuelve a descargar."
$btnLock = New-Btn "🔒 Bloquear" ($X + 670) 629 125 "Una cancion bloqueada no cambia al volver a abrir AGREGAR_CANCIONES."
foreach ($b in $btnUse, $btnSave, $btnInstr, $btnDrop, $btnLock) { $b.Anchor = "Bottom,Left" }
$btnAdd = New-Btn "➕ Agregar canciones nuevas" $X 666 190 "Convierte e identifica lo nuevo de PON_TUS_CANCIONES_AQUI."
$btnReload = New-Btn "⟳ Actualizar" ($X + 195) 666 100 ""
foreach ($b in $btnAdd, $btnReload) { $b.Anchor = "Bottom,Left" }
$status = New-Lbl "" ($X + 305) 671 490; $status.Anchor = "Bottom,Left,Right"; $status.ForeColor = [Drawing.Color]::FromArgb(255, 224, 138)

# ---------------------------------------------------------------- datos
$script:rows = @()     # una por cancion: n, archivo, nombre, data
$script:cur = $null    # la cancion elegida
$script:shownCands = @()

function Say($t) { $status.Text = $t; [Windows.Forms.Application]::DoEvents() }
function Busy($on) { $form.Cursor = $(if ($on) { [Windows.Forms.Cursors]::WaitCursor } else { [Windows.Forms.Cursors]::Default }); [Windows.Forms.Application]::DoEvents() }
function Fmt($s) { $s = [double]$s; if ($s -le 0) { return "?" }; return ("{0}:{1:00}" -f [int][Math]::Floor($s / 60), [int][Math]::Floor($s % 60)) }
function State-Of($d) {
    if ($d.bloqueada) { $lock = "🔒 " } else { $lock = "" }
    if ($d.tipo -eq "instrumental") { return @("$($lock)instrumental", [Drawing.Color]::FromArgb(110, 180, 255)) }
    if ($d.manual) { return @("$($lock)tuya", [Drawing.Color]::FromArgb(120, 230, 140)) }
    if (-not $d.fuente -or $d.tipo -eq "ninguna") { return @("$($lock)sin letra", [Drawing.Color]::FromArgb(255, 110, 110)) }
    $c = [int]$d.confianza
    if ($c -lt 0) { return @("$($lock)anterior", $textC) }
    if ($c -ge 85) { return @("$($lock)segura", [Drawing.Color]::FromArgb(120, 230, 140)) }
    if ($c -ge 70) { return @("$($lock)probable", [Drawing.Color]::FromArgb(200, 230, 120)) }
    return @("$($lock)revisar", [Drawing.Color]::FromArgb(255, 210, 90))
}
function Load-Songs {
    $names2 = @{}
    if (Test-Path $names) { foreach ($l in [IO.File]::ReadAllLines($names, $utf8)) { if ($l -match '^\s*(\d+)\s*=\s*(.+)$') { $names2[[int]$Matches[1]] = $Matches[2].Trim() } } }
    $script:rows = @()
    if (Test-Path $index) {
        foreach ($l in [IO.File]::ReadAllLines($index, $utf8)) {
            $p = $l.Split("|")
            if ($p.Count -lt 3) { continue }
            $n = [int]$p[0]
            $name = if ($names2.ContainsKey($n)) { $names2[$n] } elseif ($p.Count -ge 4) { $p[3] } else { $p[1] }
            $script:rows += [pscustomobject]@{ n = $n; archivo = $p[1]; nombre = $name; data = (Read-Data $n) }
        }
    }
    Fill-Songs
}
function Fill-Songs {
    $q = Norm-Text $search.Text
    $hint.Visible = (-not $search.Text) -and (-not $search.Focused)
    $sel = if ($script:cur) { $script:cur.n } else { -1 }
    $songs.BeginUpdate(); $songs.Items.Clear()
    foreach ($r in $script:rows) {
        $hay = Norm-Text "$($r.nombre) $($r.data.artista) $($r.data.titulo) $($r.archivo)"
        if ($q -and -not $hay.Contains($q)) { continue }
        $st = State-Of $r.data
        $it = New-Object Windows.Forms.ListViewItem([string]$r.n)
        [void]$it.SubItems.Add($r.nombre); [void]$it.SubItems.Add($st[0])
        [void]$it.SubItems.Add($(if ([int]$r.data.confianza -ge 0 -and $r.data.fuente) { "$([int]$r.data.confianza)%" } else { "" }))
        $it.ForeColor = $st[1]; $it.Tag = $r
        [void]$songs.Items.Add($it)
        if ($r.n -eq $sel) { $it.Selected = $true }
    }
    $songs.EndUpdate()
    $form.Text = "♪ Mi Música - preparar canciones ($($script:rows.Count))"
}
function Song-File($r) { return (Join-Path $src $r.archivo) }
function Ogg($r) { return (Join-Path $snd "$($r.n).ogg") }
function Show-Song($r) {
    $script:cur = $r
    $d = $r.data
    if (-not $d.duracion -or [double]$d.duracion -le 0) { $d.duracion = Get-Seconds (Ogg $r) }
    $src2 = if ($d.fuente) { "$($d.fuente), $(if ([int]$d.confianza -ge 0) { "$([int]$d.confianza)% " })$(Conf-Word ([int]$d.confianza))" } else { "sin buscar" }
    $info.Text = "[$($r.n)] $($r.archivo)`r`nDuración: $(Fmt $d.duracion) · Letra: $src2 · Tipo: $($d.tipo)$(if ($d.bloqueada) { ' · 🔒 bloqueada' })$(if (@($d.descartadas).Count) { " · $(@($d.descartadas).Count) descartada(s)" })"
    if (-not $d.artista -and -not $d.titulo) {
        $w = Get-Want (Get-Tags (Song-File $r)) ([IO.Path]::GetFileNameWithoutExtension($r.archivo)) $d.duracion
        $artist.Text = $w.artist; $title.Text = $w.title
    } else { $artist.Text = $d.artista; $title.Text = $d.titulo }
    $file = Join-Path $lrc "$($r.n).lrc"
    $text = ""
    $off = [int]$d.offset
    if (Test-Path $file) {
        $text = [IO.File]::ReadAllText($file, $utf8)
        if ($text -match "\[offset:\s*(-?\d+)\]") { $off = [int]$Matches[1] }
        $text = ($text -replace "(?m)^\[(ti|ar|al|offset|length|by|re|ve):[^\]]*\]\s*\r?\n?", "").Trim()
    }
    $lyrics.Text = ($text -replace "`r?`n", "`r`n")
    $lyrLbl.Text = $(if ($text) { "Letra actual (puedes editarla y pulsar Guardar):" } elseif ($d.tipo -eq "instrumental") { "Instrumental: sin letra." } else { "Sin letra. Busca, elige una coincidencia o escribe/pega una:" })
    $offset.Value = [Math]::Max(-10000, [Math]::Min(10000, $off))
    $btnLock.Text = $(if ($d.bloqueada) { "🔓 Desbloquear" } else { "🔒 Bloquear" })
    Fill-Cands @($d.candidatos)
}
function Fill-Cands($list) {
    $script:shownCands = @($list | Where-Object { $_ })
    $cands.BeginUpdate(); $cands.Items.Clear()
    $secs = if ($script:cur) { [double]$script:cur.data.duracion } else { 0 }
    foreach ($c in $script:shownCands) {
        $it = New-Object Windows.Forms.ListViewItem([string]$c.fuente)
        [void]$it.SubItems.Add([string]$c.artista); [void]$it.SubItems.Add([string]$c.titulo)
        [void]$it.SubItems.Add((Fmt $c.duracion))
        $dif = if ($secs -gt 0 -and [double]$c.duracion -gt 0) { "{0:+0;-0;0} s" -f [int][Math]::Round([double]$c.duracion - $secs) } else { "?" }
        [void]$it.SubItems.Add($dif)
        $kind = switch ($c.tipo) { "palabra" { "palabra ✦" } "linea" { "por línea" } "texto" { "sin tiempos" } default { $c.tipo } }
        [void]$it.SubItems.Add($kind)
        [void]$it.SubItems.Add("$([int]$c.confianza)%")
        $it.ForeColor = $(if ($c.confianza -ge 85) { [Drawing.Color]::FromArgb(120, 230, 140) } elseif ($c.confianza -ge 70) { [Drawing.Color]::FromArgb(200, 230, 120) } elseif ($c.confianza -ge 50) { [Drawing.Color]::FromArgb(255, 210, 90) } else { [Drawing.Color]::FromArgb(200, 150, 150) })
        if ($script:cur -and $c.id -eq $script:cur.data.id) { $it.Font = New-Object Drawing.Font($font, [Drawing.FontStyle]::Bold); $it.Text = "▶ " + $it.Text }
        $it.Tag = $c
        [void]$cands.Items.Add($it)
    }
    $cands.EndUpdate()
}
function Picked { if ($cands.SelectedItems.Count) { return $cands.SelectedItems[0].Tag }; return $null }
function Save-Cur {
    $r = $script:cur
    Write-Info $r.n $r.data; Write-Data $r.n $r.data
    $nm = ("$($r.data.artista) - $($r.data.titulo)").Trim(" -")
    if ($nm) { Set-Name $r.n $nm; $r.nombre = $nm }
    Fill-Songs; Show-Song $r
}
function Add-Cand($c) {
    if (-not $c) { return }
    $d = $script:cur.data
    $d.candidatos = @($c) + @($d.candidatos | Where-Object { $_.id -ne $c.id })
    Write-Data $script:cur.n $d
    Fill-Cands @($d.candidatos)
    $cands.Items[0].Selected = $true
}
function Need-Song { if (-not $script:cur) { Say "Primero elige una canción de la lista."; return $false }; return $true }
function Current-Want {
    $d = $script:cur.data
    $w = Get-Want @{ title = $title.Text; artist = $artist.Text } $script:cur.archivo $d.duracion
    if (-not $title.Text) { $w = Get-Want @{ title = ""; artist = "" } ([IO.Path]::GetFileNameWithoutExtension($script:cur.archivo)) $d.duracion }
    return $w
}

# ---------------------------------------------------------------- acciones
$search.Add_TextChanged({ Fill-Songs })
$search.Add_GotFocus({ $hint.Visible = $false })
$search.Add_LostFocus({ $hint.Visible = -not $search.Text })
$songs.Add_SelectedIndexChanged({ if ($songs.SelectedItems.Count) { Show-Song $songs.SelectedItems[0].Tag } })
$cands.Add_SelectedIndexChanged({
    $c = Picked
    if (-not $c) { return }
    if ($c.tipo -eq "instrumental") { $lyrics.Text = "(instrumental: esta versión no tiene letra)" }
    else { $lyrics.Text = ("$($c.letra)" -replace "`r?`n", "`r`n") }
    $lyrLbl.Text = "Vista previa de $($c.fuente): $($c.artista) - $($c.titulo). Pulsa ✔ Usar esta para elegirla."
})
$cands.Add_DoubleClick({ $btnUse.PerformClick() })

$btnFind.Add_Click({
    if (-not (Need-Song)) { return }
    Busy $true; Say "Buscando coincidencias…"
    $script:netErr = ""
    $w = Current-Want
    $list = Find-Candidates $w (Song-File $script:cur) $script:cur.data.descartadas $true
    $script:cur.data.candidatos = Cands-ForSave $list
    Write-Data $script:cur.n $script:cur.data
    Fill-Cands @($script:cur.data.candidatos)
    Busy $false
    if ($list.Count) { Say "$($list.Count) coincidencias. La mejor: $($list[0].confianza)% ($($list[0].fuente))."; $cands.Items[0].Selected = $true }
    else { Say $(if ($script:netErr) { "Sin resultados (error de red: $($script:netErr))" } else { "Sin resultados. Prueba otro título, YouTube o la IA." }) }
})
$btnYT.Add_Click({
    if (-not (Need-Song)) { return }
    Busy $true; Say "Buscando el video en YouTube…"
    $w = Current-Want
    $c = YouTube $w.query $script:cur.data.duracion $null
    Busy $false
    if ($c) { $c.artista = $artist.Text; $c.titulo = $title.Text; Add-Cand $c; Say "Subtítulos de YouTube encontrados." } else { Say "No hay un video con subtítulos que dure igual. Prueba Pegar enlace." }
})
$btnLink.Add_Click({
    if (-not (Need-Song)) { return }
    $url = [Microsoft.VisualBasic.Interaction]::InputBox("Pega el enlace del video de YouTube de esta canción:", "Mi Música", "https://www.youtube.com/watch?v=")
    if ($url -notmatch "^https?://\S+(v=|youtu\.be/)\S+") { return }
    Busy $true; Say "Leyendo los subtítulos del video…"
    $c = YouTube "" 0 $url
    Busy $false
    if ($c) {
        $c.artista = $artist.Text; $c.titulo = $title.Text; Add-Cand $c
        $key = [IO.Path]::GetFileNameWithoutExtension($script:cur.archivo)
        [IO.File]::AppendAllText((Join-Path $src "enlaces.txt"), "$key = $url`r`n", $utf8)
        Say "Subtítulos leídos y enlace guardado en enlaces.txt."
    } else { Say "Ese video no tiene subtítulos que se puedan usar." }
})
$btnAI.Add_Click({
    if (-not (Need-Song)) { return }
    Busy $true; Say "La IA está escuchando la canción (1-2 minutos; la primera vez descarga el modelo)…"
    $t = Whisper (Ogg $script:cur) $script:cur.data.duracion
    Busy $false
    if ($t) {
        $c = New-Cand "ia" "whisper" $artist.Text $title.Text $script:cur.data.duracion "palabra" $t
        $c.confianza = 40; Add-Cand $c; Say "La IA escribió la letra. Revísala: puede tener errores."
    } else { Say "La IA no oyó voz clara. ¿Será instrumental?" }
})
$btnAlign.Add_Click({
    if (-not (Need-Song)) { return }
    $text = $lyrics.Text
    if ($text -notmatch "(?m)^\[\d+:\d+") { Say "Primero pon una letra con tiempos por línea ([mm:ss.xx])."; return }
    Busy $true; Say "La IA está escuchando cada palabra (1-2 minutos)…"
    $al = Align-Words $text (Whisper-Words (Ogg $script:cur))
    Busy $false
    if ($al) { $lyrics.Text = ($al.lrc -replace "`r?`n", "`r`n"); Say "Listo: $($al.hit)% de las palabras se oyeron. Pulsa 💾 Guardar cambios para quedártela." }
    else { Say "La IA no reconoció suficientes palabras para alinearlas." }
})
$btnOpen.Add_Click({ if (Need-Song) { $f = Song-File $script:cur; if (Test-Path $f) { Start-Process $f } else { Start-Process (Ogg $script:cur) } } })
$btnFolder.Add_Click({ Start-Process $src })

$btnUse.Add_Click({
    if (-not (Need-Song)) { return }
    $c = Picked
    if (-not $c) { Say "Elige una coincidencia de la lista."; return }
    $d = $script:cur.data
    $d.offset = [int]$offset.Value
    Apply-Cand $script:cur.n $d $c
    $d.manual = $true; $d.confianza = 100
    Save-Cur
    Say "Usando $($c.fuente): $($c.artista) - $($c.titulo). En Minecraft pulsa F3+T."
})
$btnSave.Add_Click({
    if (-not (Need-Song)) { return }
    $d = $script:cur.data
    $d.artista = $artist.Text.Trim(); $d.titulo = $title.Text.Trim(); $d.offset = [int]$offset.Value
    $text = $lyrics.Text.Trim()
    $file = Join-Path $lrc "$($script:cur.n).lrc"
    $old = if (Test-Path $file) { ([IO.File]::ReadAllText($file, $utf8) -replace "(?m)^\[(ti|ar|al|offset|length|by|re|ve):[^\]]*\]\s*\r?\n?", "").Trim() } else { "" }
    if ($text -and $text -notmatch "^\(instrumental") {
        if (($text -replace "\r", "") -ne ($old -replace "\r", "")) { $d.fuente = "manual"; $d.id = "manual" }
        $kind = Lyric-Kind $text
        if ($kind -eq "texto") { $text = Spread-Plain $text $d.duracion; $kind = "aproximada" }
        $d.tipo = $kind
        Save-Lyrics $script:cur.n $d $text $d.offset
    }
    $d.manual = $true; $d.confianza = 100
    Save-Cur
    Say "Guardado. En Minecraft pulsa F3+T para recargar."
})
$btnInstr.Add_Click({
    if (-not (Need-Song)) { return }
    $d = $script:cur.data
    $d.tipo = "instrumental"; $d.fuente = "manual"; $d.id = "instrumental"; $d.manual = $true; $d.confianza = 100
    Remove-Item (Join-Path $lrc "$($script:cur.n).lrc") -ErrorAction SilentlyContinue
    Save-Cur
    Say "Marcada como instrumental."
})
$btnDrop.Add_Click({
    if (-not (Need-Song)) { return }
    $d = $script:cur.data
    $c = Picked
    $id = if ($c) { $c.id } else { $d.id }
    if (-not $id -or $id -eq "manual" -or $id -eq "propio") { Say "Elige la coincidencia incorrecta en la lista."; return }
    $d.descartadas = @(@($d.descartadas) + $id | Select-Object -Unique)
    $d.candidatos = @($d.candidatos | Where-Object { $_.id -ne $id })
    if ($d.id -eq $id) {
        Remove-Item (Join-Path $lrc "$($script:cur.n).lrc") -ErrorAction SilentlyContinue
        $d.fuente = "ninguna"; $d.tipo = "ninguna"; $d.confianza = 0; $d.id = ""; $d.manual = $false
    }
    Save-Cur
    Say "Descartada: no se volverá a usar ni descargar."
})
$btnLock.Add_Click({
    if (-not (Need-Song)) { return }
    $script:cur.data.bloqueada = -not $script:cur.data.bloqueada
    Save-Cur
    Say $(if ($script:cur.data.bloqueada) { "Bloqueada: AGREGAR_CANCIONES no la cambiará." } else { "Desbloqueada." })
})
$btnAdd.Add_Click({
    Say "Agregando canciones nuevas en otra ventana…"
    $p = Start-Process powershell -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", "& '$(Join-Path $PSScriptRoot 'agregar.ps1')'; Read-Host 'Pulsa Enter para volver'") -PassThru
    while (-not $p.HasExited) { Start-Sleep -Milliseconds 300; [Windows.Forms.Application]::DoEvents() }
    Load-Songs; Say "Lista actualizada."
})
$btnReload.Add_Click({ Load-Songs; Say "Lista actualizada." })

Load-Songs
if (-not $script:rows.Count) { Say "Todavía no hay canciones: pulsa ➕ Agregar canciones nuevas." }
else {
    $check = @($script:rows | Where-Object { (State-Of $_.data)[0] -match "revisar|sin letra" }).Count
    Say "$($script:rows.Count) canciones. $check para revisar."
}
[void]$form.ShowDialog()
