﻿# Mi Musica 1.8 - funciones compartidas por AGREGAR_CANCIONES y PREPARAR_CANCIONES.
# Identifica cada cancion comparando su duracion y sus datos (etiquetas del archivo o su nombre)
# con varias bases de letras, y da a cada coincidencia una confianza de 0 a 100.
# Antes de cargar este archivo hay que definir $pack (la carpeta MiMusica).

$ErrorActionPreference = "Continue"
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
$inv   = [Globalization.CultureInfo]::InvariantCulture
$utf8  = New-Object Text.UTF8Encoding $false
$src   = Join-Path $pack "PON_TUS_CANCIONES_AQUI"
$snd   = Join-Path $pack "assets\musica\sounds\canciones"
$lrc   = Join-Path $pack "assets\musica\letras"
$rit   = Join-Path $pack "assets\musica\ritmo"
$infoD = Join-Path $pack "assets\musica\info"
$names = Join-Path $pack "assets\musica\canciones\nombres.txt"
$tools = Join-Path $pack "herramientas"
$datos = Join-Path $tools "datos"
$index = Join-Path $tools "indice.txt"
foreach ($d in $snd, $lrc, $rit, $infoD, $datos, (Split-Path $names)) { New-Item -ItemType Directory -Force $d | Out-Null }
if (-not (Get-Variable usarYouTube -ErrorAction SilentlyContinue)) { $usarYouTube = $true }
if (-not (Get-Variable usarIA -ErrorAction SilentlyContinue)) { $usarIA = $true }
if (-not (Get-Variable modeloIA -ErrorAction SilentlyContinue)) { $modeloIA = "base" }
if (-not (Get-Variable acoustidKey -ErrorAction SilentlyContinue)) { $acoustidKey = "" }
$script:netErr = ""

# ---------------------------------------------------------------- ffmpeg
function Get-FF {
    $f = Get-Command ffmpeg -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -First 1
    if (-not $f) { $f = Join-Path $tools "ffmpeg.exe" }
    if (-not (Test-Path $f)) {
        Write-Host "Descargando ffmpeg (solo la primera vez)..." -ForegroundColor Yellow
        $zip = Join-Path $env:TEMP "ffmpeg-mimusica.zip"
        $ProgressPreference = "SilentlyContinue"
        Invoke-WebRequest "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip" -OutFile $zip
        $tmp = Join-Path $env:TEMP "ffmpeg-mimusica"
        if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        Expand-Archive $zip $tmp
        Copy-Item (Get-ChildItem $tmp -Recurse -Filter ffmpeg.exe | Select-Object -First 1).FullName $f
        Remove-Item $zip, $tmp -Recurse -Force
        $ProgressPreference = "Continue"
    }
    return $f
}
function Get-Seconds($file) {
    $info = & $script:ff -hide_banner -i $file 2>&1 | Out-String
    if ($info -match "Duration:\s*(\d+):(\d+):(\d+(\.\d+)?)") { return [double]([int]$Matches[1] * 3600 + [int]$Matches[2] * 60 + [double]::Parse($Matches[3], $inv)) }
    return 0.0
}
function Get-Tags($file) {
    $t = @{ title = ""; artist = ""; album = "" }
    $info = & $script:ff -hide_banner -i $file 2>&1 | Out-String
    foreach ($l in ($info -split "`r?`n")) {
        if ($l -match "^\s{2,6}(title|artist|album_artist|album)\s*:\s*(.+)$") {
            $k = $Matches[1].ToLower(); $v = $Matches[2].Trim()
            if ($k -eq "album_artist") { if (-not $t.artist) { $t.artist = $v } } elseif (-not $t[$k]) { $t[$k] = $v }
        }
        if ($l -match "^\s*Stream #") { break }
    }
    return $t
}

# ---------------------------------------------------------------- texto
function Clean($t) {
    $t = "$t"
    $t = $t -replace "(?i)\b(www\.)?[a-z0-9-]+\.(cc|com|net|org|io|to|me|info|xyz|ru|co)\b", " "
    $t = $t -replace "(?i)^(y2mate|savefrom|spotisaver|ytmp3|mp3juice|notube|flvto|tubidy)\s*[-_:]?\s*", ""
    $t = $t -replace "\(.*?\)|\[.*?\]|\{.*?\}|【.*?】|「|」", " "
    $t = $t -replace "(?i)\b(official|oficial|video|music|musica|audio|lyrics?|letra|visualizer|hd|hq|4k|1080p|720p|remaster(ed)?|en vivo|live|mv|pv|full|version|explicit)\b", " "
    $t = $t -replace "(?i)\s(ft\.?|feat\.?|featuring)\s.*$", " "
    $t = $t -replace "^\s*\d{1,3}\s*[-_.)]\s+", ""
    $t = $t -replace "[_|]", " " -replace "\s+", " "
    return $t.Trim(" -.")
}
# Minusculas, sin acentos ni signos.
function Norm-Text($s) {
    $s = "$s".ToLowerInvariant().Normalize([Text.NormalizationForm]::FormD)
    $sb = New-Object Text.StringBuilder
    foreach ($c in $s.ToCharArray()) {
        $cat = [Globalization.CharUnicodeInfo]::GetUnicodeCategory($c)
        if ($cat -eq [Globalization.UnicodeCategory]::NonSpacingMark) { continue }
        if ([char]::IsLetterOrDigit($c)) { [void]$sb.Append($c) } else { [void]$sb.Append(' ') }
    }
    return ($sb.ToString() -replace "\s+", " ").Trim()
}
$script:stop = @("the","a","el","la","los","las","de","del","y","and","feat","ft","featuring","official","video","audio","lyrics","letra","oficial","remix","x","con","with","prod","by","unknown","desconocido","artist","artista","track","pista","song","cancion")
function Tokens($s) {
    $out = @()
    foreach ($w in ((Norm-Text $s) -split " ")) { if ($w -and ($script:stop -notcontains $w)) { $out += $w } }
    return ,$out
}
# 0..1: que tanto se parecen dos textos (palabras en comun). -1 si alguno esta vacio.
function Similar($a, $b) {
    $na = Norm-Text $a; $nb = Norm-Text $b
    if (-not $na -or -not $nb) { return -1.0 }
    if ($na -eq $nb) { return 1.0 }
    $ta = Tokens $a; $tb = Tokens $b
    if ($ta.Count -eq 0 -or $tb.Count -eq 0) { if ($na.Contains($nb) -or $nb.Contains($na)) { return 0.8 } else { return 0.0 } }
    $common = 0
    foreach ($w in ($ta | Select-Object -Unique)) {
        foreach ($v in $tb) { if ($w -eq $v -or ($w.Length -ge 4 -and $v.Length -ge 4 -and ($w.StartsWith($v) -or $v.StartsWith($w)))) { $common++; break } }
    }
    $ua = @($ta | Select-Object -Unique).Count; $ub = @($tb | Select-Object -Unique).Count
    $cover = $common / [Math]::Min($ua, $ub)
    $jac = $common / [Math]::Max(1, ($ua + $ub - $common))
    return [Math]::Min(1.0, 0.65 * $cover + 0.35 * $jac)
}
function Dur-Score($d, $secs) {
    if ($secs -le 0 -or $d -le 0) { return 0.5 }
    $x = [Math]::Abs($d - $secs)
    if ($x -le 1.5) { return 1.0 }
    if ($x -le 3) { return 0.9 }
    if ($x -le 6) { return 0.7 }
    if ($x -le 10) { return 0.4 }
    if ($x -le 15) { return 0.15 }
    return 0.0
}

# Lo que se sabe de la cancion: etiquetas o nombre del archivo, y su duracion.
function Get-Want($tags, $baseName, $secs) {
    $w = @{ artist = ""; title = ""; query = ""; secs = [double]$secs; instrumental = $false; raw = "$baseName $($tags.title)" }
    $clean = Clean $baseName
    if ($tags.title) {
        $w.title = Clean $tags.title
        $w.artist = "$($tags.artist)".Trim()
    } elseif ($clean -match "^(.+?)\s+-\s+(.+)$") {
        $w.artist = $Matches[1].Trim(); $w.title = $Matches[2].Trim()
    } else { $w.title = $clean }
    if (-not $w.title) { $w.title = $baseName }
    $w.query = ("$($w.artist) $($w.title)").Trim()
    if ("$baseName $($tags.title)" -match "(?i)\b(instrumental|karaoke|type beat|8.?bit|ost|bgm|lo-?fi beat)\b") { $w.instrumental = $true }
    return $w
}

$script:versions = @("remix", "live", "en vivo", "acoustic", "acustic[oa]", "cover", "sped up", "slowed", "nightcore", "instrumental", "karaoke", "8d", "mashup", "edit", "version")
# Confianza 0..99 de que una letra encontrada sea la de esta cancion.
function Score-Cand($c, $want) {
    $ds = Dur-Score ([double]$c.duracion) $want.secs
    $ts = Similar $want.title $c.titulo
    $as = Similar $want.artist $c.artista
    if ($ts -lt 0) { $ts = 0.5 }
    $tRaw = $ts
    # Sin artista conocido: se compara todo el texto con "artista titulo".
    if ($as -lt 0) { $as = [Math]::Max(0.4, (Similar $want.query "$($c.artista) $($c.titulo)")) }
    # El titulo buscado puede traer al artista pegado ("Artista Titulo").
    $ts = [Math]::Max($ts, 0.9 * (Similar $want.query "$($c.artista) $($c.titulo)"))
    $s = 100 * (0.45 * $ds + 0.35 * $ts + 0.20 * $as)
    if ($c.tipo -eq "palabra") { $s += 3 }
    if ($c.tipo -eq "texto") { $s -= 12 }
    if ($c.tipo -eq "instrumental" -and -not $want.instrumental) { $s -= 8 }
    # Otra version (remix, en vivo, acustica, cover...) cuando tu archivo no lo dice.
    foreach ($v in $script:versions) {
        $inC = "$($c.titulo) $($c.artista)" -match "(?i)\b$v\b"; $inW = "$($want.raw)" -match "(?i)\b$v\b"
        if ($inC -ne $inW) { $s -= 15; break }
    }
    # Si el titulo no se parece en nada, no puede ser segura aunque dure igual.
    if ($ts -lt 0.3 -or ($want.artist -and $tRaw -lt 0.3)) { $s = [Math]::Min($s, 45) }
    if ($ds -eq 0 -and $want.secs -gt 0 -and [double]$c.duracion -gt 0) { $s = [Math]::Min($s, 45) }
    return [int][Math]::Max(0, [Math]::Min(99, [Math]::Round($s)))
}
function Conf-Word($c) {
    if ($c -ge 100) { return "manual" }
    if ($c -ge 85) { return "alta" }
    if ($c -ge 70) { return "media" }
    if ($c -ge 0) { return "baja" }
    return "?"
}

# ---------------------------------------------------------------- red
$headers = @{ "User-Agent" = "MiMusica/1.8 (reproductor de Minecraft)" }
function Get-Json($url, $h) {
    if (-not $h) { $h = $headers }
    $last = ""
    for ($t = 0; $t -lt 3; $t++) {
        try {
            $r = Invoke-RestMethod $url -Headers $h -TimeoutSec 20 -ErrorAction Stop
            # Algunas bases responden JSON como texto (o envuelto en callback(...)).
            if ($r -is [string]) {
                $j = $r.Trim() -replace "^[A-Za-z_$][\w$]*\(", "" -replace "\)\s*;?\s*$", ""
                try { $r = $j | ConvertFrom-Json -ErrorAction Stop } catch { }
            }
            return $r
        }
        catch {
            $last = $_.Exception.Message
            if ($last -match "404") { return $null }
            Start-Sleep -Seconds (1 + $t * 2)
        }
    }
    $script:netErr = $last
    return $null
}
function Items($r) {
    # PowerShell 5 a veces devuelve la lista entera como un solo objeto.
    $out = @()
    foreach ($x in @($r)) { foreach ($y in @($x)) { if ($null -ne $y) { $out += $y } } }
    return ,$out
}
function Num($v) {
    $d = 0.0
    foreach ($x in @($v)) { if ($null -ne $x) { [void][double]::TryParse([string]$x, [Globalization.NumberStyles]::Float, $inv, [ref]$d); break } }
    return $d
}
function T($sec) { return [string]::Format($inv, "{0:00}:{1:00.00}", [Math]::Floor($sec / 60), ($sec % 60)) }
function Secs($stamp) {
    $v = 0.0
    foreach ($x in $stamp.Split(":")) { $v = $v * 60 + [double]::Parse($x, $inv) }
    return $v
}
function New-Cand($fuente, $id, $artista, $titulo, $duracion, $tipo, $letra) {
    $artista = ("$artista" -replace "\s+", " ").Trim(); $titulo = ("$titulo" -replace "\s+", " ").Trim()
    return [pscustomobject]@{ id = "${fuente}:$id"; fuente = $fuente; artista = "$artista"; titulo = "$titulo"; duracion = [double]$duracion; tipo = $tipo; letra = "$letra"; confianza = 0 }
}
function Lyric-Kind($text) {
    if ($text -match "\]\s*<\d+:\d+") { return "palabra" }
    if ($text -match "(?m)^\[\d+:\d+") { return "linea" }
    return "texto"
}

# lrclib.net: la busqueda exacta (firma) y la busqueda libre.
function From-Lrclib($x) {
    if ($x.instrumental -eq $true) { return New-Cand "lrclib" $x.id $x.artistName $x.trackName (Num $x.duration) "instrumental" "" }
    if ($x.syncedLyrics) { return New-Cand "lrclib" $x.id $x.artistName $x.trackName (Num $x.duration) (Lyric-Kind $x.syncedLyrics) $x.syncedLyrics }
    if ($x.plainLyrics) { return New-Cand "lrclib" $x.id $x.artistName $x.trackName (Num $x.duration) "texto" $x.plainLyrics }
    return $null
}
function Search-Lrclib($want) {
    $out = @()
    $api = "https://lrclib.net/api"
    $e = { param($s) [uri]::EscapeDataString("$s") }
    if ($want.artist -and $want.title -and $want.secs -gt 0) {
        $r = Get-Json ("$api/get?artist_name=" + (& $e $want.artist) + "&track_name=" + (& $e $want.title) + "&duration=" + [int][Math]::Round($want.secs))
        if ($r -and $r.id) { $c = From-Lrclib $r; if ($c) { $out += $c } }
    }
    $qs = @()
    if ($want.artist -and $want.title) { $qs += "artist_name=" + (& $e $want.artist) + "&track_name=" + (& $e $want.title) }
    if ($want.query) { $qs += "q=" + (& $e $want.query) }
    if ($want.title) { $qs += "track_name=" + (& $e $want.title) }
    foreach ($q in ($qs | Select-Object -Unique)) {
        foreach ($x in (Items (Get-Json "$api/search?$q"))) { if ($x.id) { $c = From-Lrclib $x; if ($c) { $out += $c } } }
        if ($out.Count -ge 12) { break }
    }
    return ,$out
}

# NetEase: muchisimas canciones (latino, anime, k-pop...) y a veces letra palabra por palabra (yrc).
function Yrc-ToLrc($yrc) {
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($l in ($yrc -split "`n")) {
        if ($l -notmatch "^\[(\d+),(\d+)\](.*)$") { continue }
        $start = [double]$Matches[1] / 1000; $body = $Matches[3]
        $sb = New-Object Text.StringBuilder
        foreach ($m in [regex]::Matches($body, "\((\d+),(\d+),\d+\)([^(]*)")) {
            $w = $m.Groups[3].Value
            if (-not $w.Trim()) { continue }
            [void]$sb.Append("<" + (T ([double]$m.Groups[1].Value / 1000)) + ">" + $w)
        }
        $line = ($sb.ToString() -replace "\s+", " ").Trim()
        if ($line) { $out.Add("[" + (T $start) + "]" + $line) }
    }
    if ($out.Count -lt 4) { return "" }
    return ($out -join "`n")
}
function Clean-NetEase($text) {
    $keep = @()
    foreach ($l in ($text -split "`n")) {
        if ($l -notmatch "^\[\d+:\d+") { continue }
        if ($l -match "(作词|作曲|编曲|制作|混音|母带|和声|吉他|贝斯|鼓|监制|出品|录音|原歌词有误|Lyricist|Composer|Arranger|Producer)\s*[:：]?") { continue }
        $keep += $l.TrimEnd()
    }
    return ($keep -join "`n")
}
function Search-NetEase($want) {
    $out = @()
    $nh = @{ "User-Agent" = "Mozilla/5.0"; "Referer" = "https://music.163.com" }
    $songs = @()
    foreach ($q in @($want.query, $want.title) | Where-Object { $_ } | Select-Object -Unique) {
        try {
            $r = Invoke-RestMethod ("https://music.163.com/api/cloudsearch/pc?type=1&limit=10&s=" + [uri]::EscapeDataString($q)) -Method Post -Headers $nh -TimeoutSec 20 -ErrorAction Stop
            $songs += Items $r.result.songs
        } catch { $script:netErr = "$_" }
        if ($songs.Count -ge 6) { break }
    }
    $seen = @{}
    # Solo se descargan las letras de las 4 que mejor encajan (por nombre y duracion).
    $ranked = @($songs | Where-Object { $_ -and $_.id } | ForEach-Object {
        $ar = (@($_.ar) | ForEach-Object { $_.name }) -join ", "
        $c = New-Cand "netease" (@($_.id)[0]) $ar $_.name ((Num $_.dt) / 1000) "linea" ""
        $c.confianza = Score-Cand $c $want
        $c
    } | Sort-Object confianza -Descending)
    foreach ($c in $ranked) {
        if ($seen[$c.id]) { continue }
        $seen[$c.id] = 1
        if ($seen.Count -gt 4) { break }
        try {
            $id = $c.id.Split(":")[1]
            $l = Invoke-RestMethod ("https://music.163.com/api/song/lyric/v1?id=$id&lv=-1&kv=-1&tv=-1&yv=-1") -Headers $nh -TimeoutSec 20 -ErrorAction Stop
            $plain = Clean-NetEase ([string]$l.lrc.lyric)
            $yrc = ""
            if ($l.yrc -and $l.yrc.lyric) { $yrc = Yrc-ToLrc ([string]$l.yrc.lyric) }
            if ("$($l.lrc.lyric)" -match "纯音乐") { $c.tipo = "instrumental"; $out += $c; continue }
            if ($yrc) { $c.letra = $yrc; $c.tipo = "palabra"; $out += $c }
            elseif (@($plain -split "`n").Count -ge 4) { $c.letra = $plain; $c.tipo = Lyric-Kind $plain; $out += $c }
        } catch { $script:netErr = "$_" }
    }
    return ,$out
}

# Megalobiz: letras sincronizadas hechas a mano.
function Search-Megalobiz($want) {
    $out = @()
    try {
        $api = "https://api.megalobiz.com/api/public/v1"
        $url = "$api/search?limit=6&q=" + [uri]::EscapeDataString($want.query)
        if ($want.secs -gt 0) { $url += "&duration=" + [int]$want.secs }
        $r = Invoke-RestMethod $url -Headers $headers -TimeoutSec 15 -ErrorAction Stop
        foreach ($x in (Items $r.results) | Select-Object -First 3) {
            if ($want.secs -gt 0 -and [Math]::Abs((Num $x.duration) - $want.secs) -gt 15) { continue }
            $t = "$(Invoke-RestMethod $x.lrc_url -Headers $headers -TimeoutSec 15)"
            if ($t -notmatch "\[\d+:\d+") { continue }
            $t = $t -replace "(?m)^\[(ti|ar|al|length|re|ve|by):[^\]]*\]\s*$", ""
            $out += New-Cand "megalobiz" $x.id $x.artist $x.title (Num $x.duration) (Lyric-Kind $t) $t.Trim()
        }
    } catch { }
    return ,$out
}

# MusicBrainz: no tiene letras, pero dice el artista y titulo reales de una grabacion con esa
# duracion. Sirve cuando el archivo se llama raro ("y2mate 1234").
function Guess-MusicBrainz($want) {
    $out = @()
    try {
        $q = 'recording:"' + ($want.title -replace '"', '') + '"'
        if ($want.artist) { $q += ' AND artist:"' + ($want.artist -replace '"', '') + '"' }
        if ($want.secs -gt 0) { $q += " AND dur:[" + [int](($want.secs - 4) * 1000) + " TO " + [int](($want.secs + 4) * 1000) + "]" }
        $r = Get-Json ("https://musicbrainz.org/ws/2/recording?fmt=json&limit=5&query=" + [uri]::EscapeDataString($q))
        foreach ($x in (Items $r.recordings)) {
            $ar = (@($x.'artist-credit') | ForEach-Object { $_.name }) -join ", "
            $out += @{ artist = $ar; title = $x.title; secs = (Num $x.length) / 1000 }
        }
    } catch { }
    return ,$out
}

# AcoustID (opcional): reconoce la cancion por como suena, aunque el archivo no diga nada.
# Pide una clave gratis en https://acoustid.org/new-application y ponla en $acoustidKey.
function Need-Fpcalc {
    $f = Join-Path $tools "fpcalc.exe"
    if (-not (Test-Path $f)) {
        try {
            $ProgressPreference = "SilentlyContinue"
            $z = Join-Path $env:TEMP "chromaprint-mimusica.zip"
            Invoke-WebRequest "https://github.com/acoustid/chromaprint/releases/download/v1.5.1/chromaprint-fpcalc-1.5.1-windows-x86_64.zip" -OutFile $z
            $tmp = Join-Path $env:TEMP "chromaprint-mimusica"
            Expand-Archive $z $tmp -Force
            Copy-Item (Get-ChildItem $tmp -Recurse -Filter fpcalc.exe | Select-Object -First 1).FullName $f
            Remove-Item $z, $tmp -Recurse -Force
            $ProgressPreference = "Continue"
        } catch { return $null }
    }
    return $f
}
function Guess-AcoustID($file) {
    $out = @()
    if (-not $acoustidKey) { return ,$out }
    try {
        $fp = Need-Fpcalc
        if (-not $fp) { return ,$out }
        $j = & $fp -json $file 2>$null | Out-String | ConvertFrom-Json
        $body = "client=$acoustidKey&meta=recordings&duration=" + [int]$j.duration + "&fingerprint=" + $j.fingerprint
        $r = Invoke-RestMethod "https://api.acoustid.org/v2/lookup" -Method Post -Body $body -ContentType "application/x-www-form-urlencoded" -TimeoutSec 20
        foreach ($res in (Items $r.results) | Where-Object { $_.score -gt 0.6 } | Select-Object -First 2) {
            foreach ($rec in (Items $res.recordings) | Select-Object -First 2) {
                $ar = (@($rec.artists) | ForEach-Object { $_.name }) -join ", "
                if ($rec.title) { $out += @{ artist = $ar; title = $rec.title; secs = (Num $rec.duration); score = $res.score } }
            }
        }
    } catch { }
    return ,$out
}

# ---------------------------------------------------------------- mas fuentes (1.8)
$script:web = @{ "User-Agent" = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36"; "Accept-Language" = "es-ES,es;q=0.9,en;q=0.8" }
function Get-Page($url, $h) {
    if (-not $h) { $h = $script:web }
    try { return [string](Invoke-WebRequest $url -Headers $h -TimeoutSec 15 -UseBasicParsing -ErrorAction Stop).Content } catch { return "" }
}
# Quita las lineas de creditos (compositor, productor...) y la del titulo que ponen algunas bases.
function Clean-Credits($text, $artista, $titulo) {
    $keep = @(); $first = $true
    foreach ($l in ($text -split "`r?`n")) {
        if ($l -match "^\[(ti|ar|al|by|offset|length|re|ve|id|hash|total|sign|qq|kuwo|language):") { continue }
        $body = ($l -replace "^(\[\d+:\d+(\.\d+)?\])+", "") -replace "<\d+:\d+(\.\d+)?>", ""
        if ($body -match "(作词|作曲|编曲|制作|混音|母带|和声|监制|出品|录音|词：|曲：|Composed by|Written by|Lyrics by|Produced by|Prod\. by|Mixed by|Mastered by|Recorded by|Engineered by|Lyricist|Composer|Arranger|Producer|Producido por|Letra de|Compuesta por)\s*[:：]?") { continue }
        if ($first -and $body -and $titulo -and $body -match [regex]::Escape(($titulo -replace "\s*\(.*$", "")) -and $body -match " - ") { $first = $false; continue }
        if ($body.Trim()) { $first = $false }
        $keep += $l.TrimEnd()
    }
    return (($keep -join "`n").Trim())
}
# Texto de una pagina HTML (los <br> como saltos de linea).
function Html-Text($html) {
    $t = $html -replace "(?i)<br\s*/?>", "`n" -replace "(?i)</p>\s*", "`n`n" -replace "(?i)</div>", "`n" -replace "<[^>]+>", ""
    $t = [Net.WebUtility]::HtmlDecode($t)
    $t = ($t -split "`n" | ForEach-Object { $_.Trim() }) -join "`n"
    $t = $t -replace "`n{3,}", "`n`n"
    return $t.Trim()
}
# Las letras de texto traen [Coro], [Verso 1]... fuera.
function Clean-Plain($t) {
    $t = ($t -split "`n" | Where-Object { $_ -notmatch "^\s*\[[^\]]*\]\s*$" -and $_ -notmatch "(?i)^\s*\d+\s*contributors?" -and $_ -notmatch "(?i)embed\s*$" }) -join "`n"
    return (($t -replace "`n{3,}", "`n`n").Trim())
}

# Kugou: enorme (latino, pop, anime...), letras sincronizadas.
function Search-Kugou($want) {
    $out = @()
    try {
        $r = Get-Json ("http://mobilecdn.kugou.com/api/v3/search/song?format=json&page=1&pagesize=8&keyword=" + [uri]::EscapeDataString($want.query)) $script:web
        $songs = @((Items $r.data.info) | ForEach-Object {
            $c = New-Cand "kugou" $_.hash $_.singername ($_.songname -replace "\s*\((Explicit|Live)\)", "") (Num $_.duration) "linea" ""
            $c.confianza = Score-Cand $c $want; $c
        } | Sort-Object confianza -Descending | Select-Object -First 3)
        foreach ($c in $songs) {
            $hash = $c.id.Split(":")[1]
            $k = Get-Json ("https://krcs.kugou.com/search?ver=1&man=yes&client=mobi&keyword=&duration=" + [int]($c.duracion * 1000) + "&hash=$hash") $script:web
            $cand = (Items $k.candidates) | Select-Object -First 1
            if (-not $cand) { continue }
            $d = Get-Json ("https://lyrics.kugou.com/download?ver=1&client=pc&fmt=lrc&charset=utf8&id=$($cand.id)&accesskey=$($cand.accesskey)") $script:web
            if (-not $d.content) { continue }
            $t = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($d.content))
            $t = Clean-Credits $t $c.artista $c.titulo
            if (@($t -split "`n").Count -lt 4) { continue }
            if ($t -match "纯音乐|此歌曲为没有填词的纯音乐") { $c.tipo = "instrumental"; $c.letra = ""; $out += $c; continue }
            $c.letra = $t; $c.tipo = Lyric-Kind $t; $out += $c
        }
    } catch { }
    return ,$out
}

# QQ Music: otra base grande con letras sincronizadas.
function Search-QQ($want) {
    $out = @()
    $qh = @{ "User-Agent" = $script:web["User-Agent"]; "Referer" = "https://y.qq.com/" }
    try {
        $r = Get-Json ("https://c.y.qq.com/soso/fcgi-bin/client_search_cp?format=json&p=1&n=8&w=" + [uri]::EscapeDataString($want.query)) $qh
        $songs = @((Items $r.data.song.list) | ForEach-Object {
            $ar = (@($_.singer) | ForEach-Object { $_.name }) -join ", "
            $c = New-Cand "qqmusic" $_.songmid $ar ($_.songname -replace "\s*\((Explicit|Live)\)", "") (Num $_.interval) "linea" ""
            $c.confianza = Score-Cand $c $want; $c
        } | Sort-Object confianza -Descending | Select-Object -First 3)
        foreach ($c in $songs) {
            $mid = $c.id.Split(":")[1]
            $l = Get-Json ("https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?format=json&nobase64=1&g_tk=5381&songmid=$mid") $qh
            if (-not $l.lyric) { continue }
            $t = [Net.WebUtility]::HtmlDecode([string]$l.lyric)
            if ($t -match "此歌曲为没有填词的纯音乐") { $c.tipo = "instrumental"; $out += $c; continue }
            $t = Clean-Credits $t $c.artista $c.titulo
            if (@($t -split "`n").Count -lt 4) { continue }
            $c.letra = $t; $c.tipo = Lyric-Kind $t; $out += $c
        }
    } catch { }
    return ,$out
}

# Musixmatch: la base mas grande; a veces palabra por palabra. Puede pedir verificacion: si
# falla, simplemente no aporta nada.
$script:mxmToken = ""
function Search-Musixmatch($want) {
    $out = @()
    if (-not $want.title) { return ,$out }
    $mh = @{ "User-Agent" = $script:web["User-Agent"]; "Cookie" = "AWSELB=0; AWSELBCORS=0; x-mxm-token-guid=" }
    $api = "https://apic-desktop.musixmatch.com/ws/1.1"
    try {
        if (-not $script:mxmToken) {
            $t = Get-Json "$api/token.get?app_id=web-desktop-app-v1.0&format=json" $mh
            $tok = "$($t.message.body.user_token)"
            if (-not $tok -or $tok -match "^0+$") { return ,$out }
            $script:mxmToken = $tok
        }
        $q = "format=json&namespace=lyrics_richsynched&subtitle_format=lrc&app_id=web-desktop-app-v1.0&usertoken=$($script:mxmToken)&q_track=" + [uri]::EscapeDataString($want.title)
        if ($want.artist) { $q += "&q_artist=" + [uri]::EscapeDataString($want.artist) }
        if ($want.secs -gt 0) { $q += "&q_duration=" + [int]$want.secs + "&f_subtitle_length=" + [int]$want.secs + "&f_subtitle_length_max_deviation=3" }
        $r = Get-Json "$api/macro.subtitles.get?$q" $mh
        $calls = $r.message.body.macro_calls
        $tr = $calls.'matcher.track.get'.message.body.track
        if (-not $tr) { return ,$out }
        $c = New-Cand "musixmatch" $tr.track_id $tr.artist_name $tr.track_name (Num $tr.track_length) "linea" ""
        if ($tr.instrumental -eq 1) { $c.tipo = "instrumental"; return ,@($c) }
        # Palabra por palabra (richsync).
        if ($tr.has_richsync -eq 1) {
            $rs = Get-Json "$api/track.richsync.get?format=json&app_id=web-desktop-app-v1.0&usertoken=$($script:mxmToken)&track_id=$($tr.track_id)" $mh
            $body = "$($rs.message.body.richsync.richsync_body)"
            if ($body) {
                $lines = New-Object System.Collections.Generic.List[string]
                foreach ($ln in ($body | ConvertFrom-Json)) {
                    $sb = New-Object Text.StringBuilder
                    $word = ""; $wat = -1.0
                    foreach ($ch in @($ln.l)) {
                        if ("$($ch.c)" -eq " ") { if ($word) { [void]$sb.Append("<" + (T ($ln.ts + $wat)) + ">" + $word + " ") }; $word = ""; $wat = -1.0; continue }
                        if ($wat -lt 0) { $wat = [double]$ch.o }
                        $word += "$($ch.c)"
                    }
                    if ($word) { [void]$sb.Append("<" + (T ($ln.ts + $wat)) + ">" + $word) }
                    $s = $sb.ToString().Trim()
                    if ($s) { $lines.Add("[" + (T ([double]$ln.ts)) + "]" + $s) }
                }
                if ($lines.Count -ge 4) {
                    $w = New-Cand "musixmatch" "$($tr.track_id)w" $tr.artist_name $tr.track_name (Num $tr.track_length) "palabra" ($lines -join "`n")
                    $out += $w
                }
            }
        }
        $sub = "$($calls.'track.subtitles.get'.message.body.subtitle_list[0].subtitle.subtitle_body)"
        if ($sub -and @($sub -split "`n").Count -ge 4) { $c.letra = $sub.Trim(); $c.tipo = Lyric-Kind $sub; $out += $c }
        else {
            $pl = "$($calls.'track.lyrics.get'.message.body.lyrics.lyrics_body)"
            $pl = ($pl -split "\*{7}")[0].Trim()
            if ($pl -and @($pl -split "`n").Count -ge 4) { $c.letra = $pl; $c.tipo = "texto"; $out += $c }
        }
    } catch { }
    return ,$out
}

# Letras.com: la mejor para canciones en espanol y portugues (texto sin tiempos).
function Search-Letras($want) {
    $out = @()
    try {
        $raw = Get-Page ("https://solr.sscdn.co/letras/m1/?wt=json&rows=4&q=" + [uri]::EscapeDataString($want.query))
        $raw = $raw -replace "^[^(]*\(", "" -replace "\)\s*;?\s*$", ""
        if (-not $raw) { return ,$out }
        $docs = @((Items ($raw | ConvertFrom-Json).response.docs) | Where-Object { $_.t -eq "2" -and $_.url -and $_.dns })
        foreach ($x in ($docs | Select-Object -First 2)) {
            $c = New-Cand "letras.com" $x.id $x.art $x.txt 0 "texto" ""
            if ((Score-Cand $c $want) -lt 35) { continue }
            $html = Get-Page "https://www.letras.com/$($x.dns)/$($x.url)/"
            $m = [regex]::Match($html, '(?s)<div class="lyric-original[^"]*">(.*?)</div>')
            if (-not $m.Success) { continue }
            $t = Clean-Plain (Html-Text $m.Groups[1].Value)
            if (@($t -split "`n").Count -lt 4) { continue }
            $c.letra = $t; $out += $c
        }
    } catch { }
    return ,$out
}

# Genius: casi todas las canciones con letra (texto sin tiempos).
function Search-Genius($want) {
    $out = @()
    try {
        $r = Get-Json ("https://genius.com/api/search/song?per_page=4&q=" + [uri]::EscapeDataString($want.query)) $script:web
        $hits = @(foreach ($sec in (Items $r.response.sections)) { foreach ($hh in (Items $sec.hits)) { if ($hh.result.url) { $hh.result } } })
        foreach ($x in ($hits | Select-Object -First 2)) {
            $c = New-Cand "genius" $x.id $x.primary_artist.name $x.title 0 "texto" ""
            if ((Score-Cand $c $want) -lt 35) { continue }
            $html = Get-Page $x.url
            $parts = [regex]::Matches($html, '(?s)<div[^>]*data-lyrics-container="true"[^>]*>(.*?)</div>(?=\s*(<div[^>]*data-lyrics-container|<div class="LyricsFooter|<div class="RightSidebar|</div>))')
            if (-not $parts.Count) { continue }
            $t = Clean-Plain ((@($parts | ForEach-Object { Html-Text $_.Groups[1].Value }) -join "`n"))
            if (@($t -split "`n").Count -lt 4) { continue }
            $c.letra = $t; $out += $c
        }
    } catch { }
    return ,$out
}

# AZLyrics: muchas canciones en ingles (texto sin tiempos).
function Search-AZLyrics($want) {
    $out = @()
    if (-not $want.artist -or -not $want.title) { return ,$out }
    try {
        $a = ((Norm-Text $want.artist) -replace "^the ", "" -replace "[^a-z0-9]", "")
        $t = ((Norm-Text ($want.title -replace "\s*[\(\[].*$", "")) -replace "[^a-z0-9]", "")
        if (-not $a -or -not $t) { return ,$out }
        $html = Get-Page "https://www.azlyrics.com/lyrics/$a/$t.html"
        $m = [regex]::Match($html, '(?s)<!-- Usage of azlyrics\.com content.*?-->(.*?)</div>')
        if (-not $m.Success) { return ,$out }
        $txt = Clean-Plain (Html-Text $m.Groups[1].Value)
        if (@($txt -split "`n").Count -ge 4) { $out += New-Cand "azlyrics" "$a/$t" $want.artist $want.title 0 "texto" $txt }
    } catch { }
    return ,$out
}

# lyrics.ovh: una API sencilla (texto sin tiempos).
function Search-LyricsOvh($want) {
    $out = @()
    if (-not $want.artist -or -not $want.title) { return ,$out }
    try {
        $r = Get-Json ("https://api.lyrics.ovh/v1/" + [uri]::EscapeDataString($want.artist) + "/" + [uri]::EscapeDataString($want.title))
        $t = Clean-Plain ("$($r.lyrics)" -replace "`r", "" -replace '^\[Letra de "[^"]*"\]\s*', "")
        if (@($t -split "`n").Count -ge 4) { $out += New-Cand "lyrics.ovh" "$($want.artist)/$($want.title)" $want.artist $want.title 0 "texto" $t }
    } catch { }
    return ,$out
}

# Lyricsify: letras .lrc subidas por usuarios.
function Search-Lyricsify($want) {
    $out = @()
    try {
        $html = Get-Page ("https://www.lyricsify.com/search?q=" + [uri]::EscapeDataString($want.query))
        $links = [regex]::Matches($html, 'href="(/lyrics/[^"]+)"[^>]*>\s*([^<]+)</a>') | Select-Object -First 2
        foreach ($m in $links) {
            $name = [Net.WebUtility]::HtmlDecode($m.Groups[2].Value).Trim()
            $ar = ""; $ti = $name
            if ($name -match "^(.+?)\s+-\s+(.+)$") { $ar = $Matches[1]; $ti = $Matches[2] }
            $c = New-Cand "lyricsify" $m.Groups[1].Value $ar $ti 0 "linea" ""
            if ((Score-Cand $c $want) -lt 40) { continue }
            $page = Get-Page ("https://www.lyricsify.com" + $m.Groups[1].Value)
            $b = [regex]::Match($page, '(?s)<div[^>]*id="lyrics_[^"]*"[^>]*>(.*?)</div>')
            if (-not $b.Success) { continue }
            $t = Clean-Credits (Html-Text $b.Groups[1].Value) $ar $ti
            if (@($t -split "`n" | Where-Object { $_ -match "^\[\d+:\d+" }).Count -lt 4) { continue }
            $len = [regex]::Match($t, "(?m)^\[length:\s*(\d+):(\d+)")
            if ($len.Success) { $c.duracion = [int]$len.Groups[1].Value * 60 + [int]$len.Groups[2].Value }
            $c.letra = $t; $c.tipo = Lyric-Kind $t; $out += $c
        }
    } catch { }
    return ,$out
}

# Las fuentes que hay, para el modo diagnostico y el preparador.
$script:fuentesSinc = @("lrclib", "NetEase", "Kugou", "QQ Music", "Musixmatch", "Megalobiz", "Lyricsify")
$script:fuentesTexto = @("Letras.com", "Genius", "AZLyrics", "lyrics.ovh")

# Todas las coincidencias de todas las fuentes, con su confianza, la mejor primero.
# $file: el audio (para AcoustID). $skip: ids descartados por el jugador.
function Find-Candidates($want, $file, $skip, $todas) {
    $all = @()
    $wants = @($want)
    foreach ($g in (Guess-AcoustID $file)) {
        $w2 = Get-Want @{ title = $g.title; artist = $g.artist } "" $want.secs
        $w2.acoustid = $true
        $wants = @($w2) + $wants
    }
    $w0 = $wants[0]
    $best = { ($all | Where-Object { $_ } | ForEach-Object { Score-Cand $_ $want } | Measure-Object -Maximum).Maximum }
    # 1) Las que tienen tiempos (sincronizadas), una tras otra hasta tener una segura.
    $all += Search-Lrclib $w0
    $all += Search-NetEase $w0
    if ($todas -or -not (& $best) -or (& $best) -lt 85) { $all += Search-Kugou $w0 }
    if ($todas -or -not (& $best) -or (& $best) -lt 85) { $all += Search-QQ $w0 }
    if ($todas -or -not (& $best) -or (& $best) -lt 85) { $all += Search-Musixmatch $w0 }
    # Poca suerte: MusicBrainz sugiere el nombre real, y se busca de nuevo con el.
    if (-not (& $best) -or (& $best) -lt 75) {
        foreach ($g in (Guess-MusicBrainz $want) | Select-Object -First 2) {
            $w2 = Get-Want @{ title = $g.title; artist = $g.artist } "" $want.secs
            $wants += $w2
            $all += Search-Lrclib $w2
            $all += Search-Kugou $w2
        }
    }
    if ($todas -or -not (& $best) -or (& $best) -lt 70) { $all += Search-Megalobiz $w0; $all += Search-Lyricsify $w0 }
    # 2) Si no hay ninguna sincronizada buena, letras de texto (luego se reparten o la IA las alinea).
    if ($todas -or -not (& $best) -or (& $best) -lt 60) {
        $all += Search-Letras $w0
        $all += Search-Genius $w0
        $all += Search-AZLyrics $w0
        $all += Search-LyricsOvh $w0
    }
    $seen = @{}; $list = @()
    foreach ($c in $all) {
        if (-not $c -or $seen[$c.id]) { continue }
        $seen[$c.id] = 1
        if ($skip -and (@($skip) -contains $c.id)) { continue }
        $sc = 0
        foreach ($w in $wants) { $sc = [Math]::Max($sc, (Score-Cand $c $w)) }
        # Lo que dice AcoustID (el sonido) vale mas que el nombre del archivo.
        if ($wants[0].acoustid) { $sc = [Math]::Max($sc, [Math]::Min(97, (Score-Cand $c $wants[0]) + 4)) }
        $c.confianza = $sc
        $list += $c
    }
    $order = @{ palabra = 0; linea = 1; instrumental = 2; texto = 3 }
    return ,@($list | Sort-Object @{ Expression = { $_.confianza }; Descending = $true }, @{ Expression = { $order[$_.tipo] } } | Select-Object -First 25)
}

# ---------------------------------------------------------------- YouTube
function Need-YtDlp {
    $y = Join-Path $tools "yt-dlp.exe"
    if (-not (Test-Path $y)) {
        Write-Host "Descargando yt-dlp (solo la primera vez)..." -ForegroundColor Yellow
        $ProgressPreference = "SilentlyContinue"
        Invoke-WebRequest "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe" -OutFile $y
        $ProgressPreference = "Continue"
    }
    $deno = Join-Path $tools "deno.exe"
    if (-not (Test-Path $deno) -and -not (Get-Command deno -ErrorAction SilentlyContinue)) {
        try {
            $ProgressPreference = "SilentlyContinue"
            $z = Join-Path $env:TEMP "deno-mimusica.zip"
            Invoke-WebRequest "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip" -OutFile $z
            Expand-Archive $z $tools -Force
            Remove-Item $z -Force
            $ProgressPreference = "Continue"
        } catch { }
    }
    if ($env:PATH -notlike "*$tools*") { $env:PATH = "$tools;$(Split-Path $script:ff);$env:PATH" }
    return $y
}
function Vtt-ToLrc($path) {
    $txt = [IO.File]::ReadAllText($path, $utf8)
    $out = New-Object System.Collections.Generic.List[string]
    $last = ""; $words = 0
    foreach ($b in ($txt -split "\r?\n\r?\n")) {
        $ls = @($b -split "\r?\n")
        $ti = -1
        for ($q = 0; $q -lt $ls.Count; $q++) { if ($ls[$q] -match "^((\d+:)?\d+:\d+\.\d+)\s+-->") { $ti = $q; $start = Secs $Matches[1]; break } }
        if ($ti -lt 0 -or $ti + 1 -ge $ls.Count) { continue }
        $body = @($ls[($ti + 1)..($ls.Count - 1)] | Where-Object { $_.Trim() })
        if ($body.Count -eq 0) { continue }
        $tagged = @($body | Where-Object { $_ -match "<\d+:\d+" })
        if ($tagged.Count -gt 0) {
            $line = $tagged[-1] -replace "</?c[^>]*>", ""
            $parts = [regex]::Split($line, "<((?:\d+:)?\d+:\d+\.\d+)>")
            $sb = New-Object Text.StringBuilder
            $at = $start; $plain = @()
            for ($q = 0; $q -lt $parts.Count; $q++) {
                if ($q % 2 -eq 1) { $at = Secs $parts[$q]; continue }
                foreach ($w in ($parts[$q] -split "\s+" | Where-Object { $_ -and $_ -notmatch "^\[.*\]$|^♪+$|^\(.*\)$" })) {
                    [void]$sb.Append("<" + (T $at) + ">" + $w + " "); $plain += $w
                }
            }
            $plainText = ($plain -join " ")
            if (-not $plainText -or $plainText -eq $last) { continue }
            $out.Add("[" + (T $start) + "]" + $sb.ToString().Trim()); $last = $plainText; $words += $plain.Count
        } else {
            $text = (($body -join " ") -replace "<[^>]+>", "" -replace "\[[^\]]*\]|♪", "" -replace "\s+", " ").Trim()
            if (-not $text -or $text -eq $last -or $last.EndsWith($text)) { continue }
            $out.Add("[" + (T $start) + "]" + $text); $last = $text; $words += ($text -split " ").Count
        }
    }
    if ($words -lt 15) { return $null }
    return ($out -join "`n")
}
function YouTube($q, $secs, $link) {
    try {
        $y = Need-YtDlp
        $tmp = Join-Path $env:TEMP "mimusica-subs"
        if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        New-Item -ItemType Directory $tmp | Out-Null
        $url = $link; $title = ""; $dur = 0.0
        if (-not $url) {
            $found = & $y --no-warnings --flat-playlist --print "%(id)s|%(duration)s|%(title)s" ("ytsearch6:" + $q) 2>$null
            foreach ($r in @($found)) {
                $p = "$r".Split("|", 3)
                if ($p.Count -lt 3) { continue }
                $d = 0.0; [void][double]::TryParse($p[1], [Globalization.NumberStyles]::Float, $inv, [ref]$d)
                if ($secs -eq 0 -or [Math]::Abs($d - $secs) -le 4) { $url = "https://www.youtube.com/watch?v=" + $p[0]; $title = $p[2]; $dur = $d; break }
            }
        }
        if (-not $url) { return $null }
        foreach ($mode in "manual", "auto") {
            $a = @("--no-warnings", "--skip-download", "--sub-format", "vtt", "-o", (Join-Path $tmp "s.%(ext)s"))
            if ($mode -eq "manual") { $a += @("--write-subs", "--sub-langs", "es.*,en.*,ja.*,ko.*,pt.*,all,-live_chat") }
            else { $a += @("--write-auto-subs", "--sub-langs", ".*-orig,es,en") }
            & $y @a $url 2>$null | Out-Null
            $files = @(Get-ChildItem $tmp -Filter *.vtt -ErrorAction SilentlyContinue)
            $pick = $files | Where-Object { $_.Name -match "-orig" } | Select-Object -First 1
            if (-not $pick) { foreach ($lang in "es", "en", "ja", "ko", "pt") { if (-not $pick) { $pick = $files | Where-Object { $_.Name -match "\.$lang" } | Select-Object -First 1 } } }
            if (-not $pick) { $pick = $files | Select-Object -First 1 }
            if ($pick) {
                $lrcText = Vtt-ToLrc $pick.FullName
                if ($lrcText) {
                    $c = New-Cand "youtube" ($url -replace ".*v=", "") "" $title $dur (Lyric-Kind $lrcText) $lrcText
                    $c.confianza = $(if ($link) { 80 } elseif ($mode -eq "manual") { 65 } else { 55 })
                    return $c
                }
            }
            Remove-Item (Join-Path $tmp "*") -Force -ErrorAction SilentlyContinue
        }
    } catch { $script:netErr = "$_" }
    return $null
}

# ---------------------------------------------------------------- IA (Whisper)
function Need-Whisper {
    $dir = Join-Path $tools "whisper"
    $exe = Get-ChildItem $dir -Recurse -Filter whisper-cli.exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $exe) {
        Write-Host "Descargando la IA que escucha las letras (solo la primera vez)..." -ForegroundColor Yellow
        $ProgressPreference = "SilentlyContinue"
        $zipUrl = "https://github.com/ggml-org/whisper.cpp/releases/download/b5907/whisper-bin-x64.zip"
        try {
            foreach ($r in @(Invoke-RestMethod "https://api.github.com/repos/ggml-org/whisper.cpp/releases?per_page=10" -Headers @{ "User-Agent" = "MiMusica" })) {
                $as = @($r.assets | Where-Object { $_.name -eq "whisper-bin-x64.zip" })
                if ($as.Count -gt 0) { $zipUrl = $as[0].browser_download_url; break }
            }
        } catch { }
        $z = Join-Path $env:TEMP "whisper-mimusica.zip"
        Invoke-WebRequest $zipUrl -OutFile $z
        Expand-Archive $z $dir -Force
        Remove-Item $z -Force
        $ProgressPreference = "Continue"
        $exe = Get-ChildItem $dir -Recurse -Filter whisper-cli.exe | Select-Object -First 1
    }
    $model = Join-Path $dir "ggml-$modeloIA.bin"
    if (-not (Test-Path $model)) {
        Write-Host "Descargando el modelo de IA '$modeloIA' (solo la primera vez)..." -ForegroundColor Yellow
        $ProgressPreference = "SilentlyContinue"
        Invoke-WebRequest "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-$modeloIA.bin" -OutFile $model
        $ProgressPreference = "Continue"
    }
    return @($exe.FullName, $model)
}
# Cada palabra que la IA oye, con su segundo: lista de @(segundo, palabra).
function Whisper-Words($ogg, $lang) {
    $words = @()
    try {
        $w = Need-Whisper
        $wav = Join-Path $env:TEMP "mimusica-voz.wav"
        $base = Join-Path $env:TEMP "mimusica-voz"
        & $script:ff -hide_banner -loglevel error -y -i $ogg -af "pan=mono|c0=0.5*c0+0.5*c1,highpass=f=150,lowpass=f=5000,dynaudnorm" -ar 16000 -ac 1 $wav
        $threads = [Math]::Max(2, [Environment]::ProcessorCount - 1)
        if (-not $lang) { $lang = "auto" }
        & $w[0] -m $w[1] -f $wav -l $lang -ml 1 -sow -olrc -of $base -np -t $threads 2>$null | Out-Null
        $file = "$base.lrc"
        if (Test-Path $file) {
            foreach ($l in [IO.File]::ReadAllLines($file, $utf8)) {
                if ($l -match "^\[(\d+):(\d+(\.\d+)?)\]\s*(.+)$") {
                    $tx = $Matches[4].Trim()
                    if ($tx -match "^\[.*\]$|^\(.*\)$|^♪|^\*" -or -not $tx) { continue }
                    $words += ,@(([int]$Matches[1] * 60 + [double]::Parse($Matches[2], $inv)), $tx)
                }
            }
        }
        Remove-Item $wav, $file -ErrorAction SilentlyContinue
    } catch { $script:netErr = "$_" }
    return ,$words
}
function Whisper($ogg, $secs) {
    $words = Whisper-Words $ogg
    if ($words.Count -lt 12) { return $null }
    $out = New-Object System.Collections.Generic.List[string]
    $cur = @(); $prev = -10.0; $seen = @{}
    $flush = {
        if ($cur.Count -gt 0) {
            $plain = ($cur | ForEach-Object { $_[1] }) -join " "
            $key = $plain.ToLower()
            $seen[$key] = 1 + [int]$seen[$key]
            if ($seen[$key] -le 6) { $out.Add("[" + (T $cur[0][0]) + "]" + (($cur | ForEach-Object { "<" + (T $_[0]) + ">" + $_[1] }) -join " ")) }
        }
    }
    foreach ($wd in $words) {
        if ($cur.Count -gt 0 -and (($wd[0] - $prev) -gt 1.4 -or $cur.Count -ge 8 -or ($cur[-1][1] -match "[.!?。！？]$" -and $cur.Count -ge 3))) { & $flush; $cur = @() }
        $cur += ,$wd; $prev = $wd[0]
    }
    & $flush
    if ($out.Count -lt 3) { return $null }
    return ($out -join "`n")
}

# Palabra por palabra: la IA escucha la cancion y cada palabra de una letra ya sincronizada por
# lineas toma el momento exacto en que se oye. Lo que la IA no oye se reparte por silabas.
function Syllables($w) {
    $n = ([regex]::Matches((Norm-Text $w), "[aeiouy]+")).Count
    return [Math]::Max(1, $n)
}
function Align-Words($text, $heard) {
    if ($heard.Count -lt 8) { return $null }
    $lines = @()
    foreach ($l in ($text -split "`r?`n")) {
        if ($l -match "^\[(\d+:\d+(\.\d+)?)\](.*)$") { $lines += ,@((Secs $Matches[1]), ($Matches[3] -replace "<[^>]+>", "").Trim(), $l) }
        else { $lines += ,@(-1, "", $l) }
    }
    $timed = @($lines | Where-Object { $_[0] -ge 0 })
    $out = New-Object System.Collections.Generic.List[string]
    $hit = 0; $total = 0
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $L = $lines[$i]
        if ($L[0] -lt 0 -or -not $L[1]) { $out.Add($L[2]); continue }
        $start = $L[0]
        $next = $null
        for ($j = $i + 1; $j -lt $lines.Count; $j++) { if ($lines[$j][0] -ge 0) { $next = $lines[$j][0]; break } }
        if ($null -eq $next) { $next = $start + 6 }
        $words = @($L[1] -split "\s+" | Where-Object { $_ })
        $pool = @($heard | Where-Object { $_[0] -ge $start - 0.6 -and $_[0] -lt $next + 0.3 })
        $times = New-Object 'double[]' $words.Count
        for ($k = 0; $k -lt $words.Count; $k++) { $times[$k] = -1 }
        $p = 0
        for ($k = 0; $k -lt $words.Count; $k++) {
            $nw = Norm-Text $words[$k]
            if (-not $nw) { continue }
            for ($q = $p; $q -lt [Math]::Min($pool.Count, $p + 4); $q++) {
                $hw = Norm-Text $pool[$q][1]
                if ($hw -and ($hw -eq $nw -or ($nw.Length -ge 3 -and $hw.Length -ge 3 -and ($hw.StartsWith($nw.Substring(0, 3)) -or $nw.StartsWith($hw.Substring(0, 3)))))) {
                    $times[$k] = [Math]::Max($start, $pool[$q][0]); $p = $q + 1; $hit++; break
                }
            }
        }
        $total += $words.Count
        # Los huecos se reparten entre las palabras vecinas que si se oyeron, por silabas.
        $span = [Math]::Min($next - $start, [Math]::Max(1.2, $words.Count * 0.42))
        $k = 0
        while ($k -lt $words.Count) {
            if ($times[$k] -ge 0) { $k++; continue }
            $a = $k; while ($k -lt $words.Count -and $times[$k] -lt 0) { $k++ }
            $from = if ($a -gt 0) { $times[$a - 1] + 0.25 } else { $start }
            $to = if ($k -lt $words.Count) { $times[$k] } else { [Math]::Max($from + 0.3, $start + $span) }
            if ($to -lt $from) { $to = $from }
            $syl = 0; for ($m = $a; $m -lt $k; $m++) { $syl += Syllables $words[$m] }
            $acc = 0
            for ($m = $a; $m -lt $k; $m++) { $times[$m] = $from + ($to - $from) * $acc / [Math]::Max(1, $syl); $acc += Syllables $words[$m] }
        }
        for ($k = 1; $k -lt $words.Count; $k++) { if ($times[$k] -lt $times[$k - 1]) { $times[$k] = $times[$k - 1] } }
        $sb = New-Object Text.StringBuilder
        for ($k = 0; $k -lt $words.Count; $k++) { [void]$sb.Append("<" + (T $times[$k]) + ">" + $words[$k] + " ") }
        $out.Add("[" + (T $start) + "]" + $sb.ToString().Trim())
    }
    # Si la IA no reconocio casi nada, no vale la pena.
    if ($total -eq 0 -or ($hit / $total) -lt 0.25) { return $null }
    return @{ lrc = ($out -join "`n"); hit = [int](100 * $hit / $total) }
}

# Letra sin tiempos repartida a lo largo de la cancion (aproximada).
function Spread-Plain($plain, $secs) {
    $ls = @($plain -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ -and $_ -notmatch "^\[" })
    if ($ls.Count -eq 0 -or $secs -le 0) { return $null }
    $from = $secs * 0.07; $step = ($secs * 0.95 - $from) / [Math]::Max(1, $ls.Count)
    $out = @()
    for ($q = 0; $q -lt $ls.Count; $q++) { $out += "[" + (T ($from + $q * $step)) + "]" + $ls[$q] }
    return ($out -join "`n")
}

# ---------------------------------------------------------------- guardar
function Data-Path($n) { return (Join-Path $datos "$n.json") }
function Read-Data($n) {
    $p = Data-Path $n
    $d = [ordered]@{ artista = ""; titulo = ""; fuente = ""; id = ""; confianza = -1; tipo = ""; bloqueada = $false; manual = $false; offset = 0; descartadas = @(); candidatos = @(); archivo = ""; duracion = 0.0 }
    if (Test-Path $p) {
        try {
            $j = [IO.File]::ReadAllText($p, $utf8) | ConvertFrom-Json
            foreach ($k in @($d.Keys)) { if ($j.PSObject.Properties[$k] -and $null -ne $j.$k) { $d[$k] = $j.$k } }
            $d.descartadas = @($d.descartadas); $d.candidatos = @($d.candidatos)
        } catch { }
    }
    return $d
}
function Write-Data($n, $d) {
    [IO.File]::WriteAllText((Data-Path $n), ($d | ConvertTo-Json -Depth 5), $utf8)
}
# Lo que el mod lee: de donde salio la letra, la confianza y si esta bloqueada.
function Write-Info($n, $d) {
    $estado = if ($d.manual) { "manual" } elseif ($d.bloqueada) { "bloqueada" } elseif ([int]$d.confianza -ge 70) { "auto" } elseif ($d.tipo) { "revisar" } else { "ninguna" }
    $lines = @(
        "fuente=$($d.fuente)",
        "confianza=$([int]$d.confianza)",
        "tipo=$($d.tipo)",
        "estado=$estado",
        "bloqueada=$(if ($d.bloqueada) { 1 } else { 0 })",
        "identificada=$((("$($d.artista) - $($d.titulo)").Trim(' -')) -replace '[\r\n=]', ' ')"
    )
    [IO.File]::WriteAllLines((Join-Path $infoD "$n.txt"), $lines, $utf8)
}
# Guarda una letra elegida como la de la cancion $n.
function Save-Lyrics($n, $d, $text, $offset) {
    $dest = Join-Path $lrc "$n.lrc"
    if (-not $text -or $d.tipo -eq "instrumental") { Remove-Item $dest -ErrorAction SilentlyContinue; return }
    $body = ($text -replace "(?m)^\[(ti|ar|al|offset|length|by|re|ve):[^\]]*\]\s*\r?\n?", "").Trim()
    $head = @()
    if ($d.titulo) { $head += "[ti:$($d.titulo)]" }
    if ($d.artista) { $head += "[ar:$($d.artista)]" }
    if ($offset) { $head += "[offset:$([int]$offset)]" }
    $head += "[re:MiMusica $($d.fuente)]"
    [IO.File]::WriteAllText($dest, (($head -join "`n") + "`n" + $body + "`n"), $utf8)
}
function Apply-Cand($n, $d, $c) {
    $d.fuente = $c.fuente; $d.id = $c.id; $d.confianza = [int]$c.confianza; $d.tipo = $c.tipo
    if ($c.artista) { $d.artista = $c.artista }
    if ($c.titulo) { $d.titulo = $c.titulo }
    $text = $c.letra
    if ($c.tipo -eq "texto") { $text = Spread-Plain $c.letra $d.duracion; $d.tipo = "aproximada" }
    Save-Lyrics $n $d $text $d.offset
    Write-Info $n $d
    Write-Data $n $d
}
function Cands-ForSave($list) {
    # Se guardan para poder elegir otra sin volver a buscar.
    return ,@($list | Select-Object -First 10 | ForEach-Object { [pscustomobject]@{ id = $_.id; fuente = $_.fuente; artista = $_.artista; titulo = $_.titulo; duracion = $_.duracion; tipo = $_.tipo; confianza = $_.confianza; letra = $_.letra } })
}
# Pone el nombre que se ve en el juego (nombres.txt) para la cancion $n.
function Set-Name($n, $name) {
    $lines = @()
    if (Test-Path $names) { $lines = @([IO.File]::ReadAllLines($names, $utf8) | Where-Object { $_ -notmatch "^\s*$n\s*=" }) }
    if (-not $lines -or $lines[0] -notmatch "^#") { $lines = @("# Numero=Nombre que se ve en el juego. Si cambias un nombre aqui, se conserva.") + $lines }
    $lines += "$n=" + ($name -replace "[\r\n=|]", " ")
    $head = @($lines | Where-Object { $_ -match "^#" })
    $rest = @($lines | Where-Object { $_ -match "^\s*(\d+)\s*=" } | Sort-Object { [int]($_ -replace "^\s*(\d+).*", '$1') })
    [IO.File]::WriteAllLines($names, ($head + $rest), $utf8)
}
