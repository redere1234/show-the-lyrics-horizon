@echo off
chcp 65001 >nul
title Mi Musica - agregar canciones
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0herramientas\agregar.ps1"
pause
