@echo off
chcp 65001 >nul
title Mi Musica - preparar canciones
powershell -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0herramientas\preparador.ps1"
if errorlevel 1 pause
